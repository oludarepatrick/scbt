-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 26, 2025 at 09:53 PM
-- Server version: 9.1.0
-- PHP Version: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `graftp_cbt`
--

-- --------------------------------------------------------

--
-- Table structure for table `ai_questions`
--

DROP TABLE IF EXISTS `ai_questions`;
CREATE TABLE IF NOT EXISTS `ai_questions` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint UNSIGNED NOT NULL,
  `curriculum_id` bigint UNSIGNED NOT NULL,
  `class` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `option_a` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `option_b` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `option_c` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `option_d` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `option_e` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `correct_option` char(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `duration` int NOT NULL,
  `source` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ai_questions_user_id_foreign` (`user_id`),
  KEY `ai_questions_curriculum_id_foreign` (`curriculum_id`)
) ENGINE=MyISAM AUTO_INCREMENT=191 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ai_questions`
--

INSERT INTO `ai_questions` (`id`, `user_id`, `curriculum_id`, `class`, `subject`, `question_text`, `option_a`, `option_b`, `option_c`, `option_d`, `option_e`, `correct_option`, `duration`, `source`, `created_at`, `updated_at`) VALUES
(1, 1, 2, 'GRADE 2', 'ENGLISH', 'What is the opposite of \'big\'?', 'Tall', 'Small', 'Long', 'Fast', NULL, 'B', 30, 'ai', '2025-10-16 23:35:16', '2025-10-17 09:01:55'),
(2, 1, 2, 'GRADE 2', 'ENGLISH', 'Which word rhymes with \'cat\'?', 'Bat', 'Dog', 'Pig', 'Bug', NULL, 'A', 30, 'ai', '2025-10-16 23:35:16', '2025-10-17 09:01:55'),
(3, 1, 2, 'GRADE 2', 'ENGLISH', 'What comes after the letter \'F\' in the alphabet?', 'H', 'G', 'J', 'E', NULL, 'B', 30, 'ai', '2025-10-16 23:35:16', '2025-10-17 09:01:55'),
(4, 1, 2, 'GRADE 2', 'ENGLISH', 'What is the plural of \'book\'?', 'Books', 'Bookes', 'Bookss', 'Boocks', NULL, 'A', 30, 'ai', '2025-10-16 23:35:16', '2025-10-17 09:01:55'),
(5, 1, 2, 'GRADE 2', 'ENGLISH', 'Which word does not belong in the group?', 'Red', 'Yellow', 'Orange', 'Bicycle', NULL, 'D', 30, 'ai', '2025-10-16 23:35:16', '2025-10-17 09:01:55'),
(6, 1, 2, 'GRADE 2', 'ENGLISH', 'What is another word for \'happy\'?', 'Sad', 'Angry', 'Joyful', 'Grumpy', NULL, 'C', 30, 'ai', '2025-10-16 23:35:16', '2025-10-17 09:01:55'),
(7, 1, 2, 'GRADE 2', 'ENGLISH', 'What is the opposite of \'day\'?', 'Moon', 'Sun', 'Night', 'Afternoon', NULL, 'C', 30, 'ai', '2025-10-16 23:35:16', '2025-10-17 09:01:55'),
(8, 1, 2, 'GRADE 2', 'ENGLISH', 'What is the plural of \'apple\'?', 'Apples', 'Apple', 'Appel', 'Applie', NULL, 'A', 30, 'ai', '2025-10-16 23:35:16', '2025-10-17 09:01:55'),
(9, 1, 2, 'GRADE 2', 'ENGLISH', 'Which word has the \'sh\' sound?', 'Cat', 'Fish', 'Dog', 'Hat', NULL, 'B', 30, 'ai', '2025-10-16 23:35:16', '2025-10-17 09:01:55'),
(10, 1, 2, 'GRADE 2', 'ENGLISH', 'What is the past tense of \'eat\'?', 'Eating', 'Ate', 'Eaten', 'Eat', NULL, 'B', 30, 'ai', '2025-10-16 23:35:16', '2025-10-17 09:01:55'),
(11, 1, 2, 'GRADE 2', 'ENGLISH', 'Which word means the opposite of \'cold\'?', 'Hot', 'Cool', 'Warm', 'Freezing', NULL, 'A', 30, 'ai', '2025-10-16 23:35:16', '2025-10-17 09:01:55'),
(12, 1, 2, 'GRADE 2', 'ENGLISH', 'What is the plural of \'car\'?', 'Cars', 'Carie', 'Car', 'Cares', NULL, 'A', 30, 'ai', '2025-10-16 23:35:16', '2025-10-17 09:01:55'),
(13, 1, 2, 'GRADE 2', 'ENGLISH', 'Which word does not belong in the group?', 'Cow', 'Pig', 'Sheep', 'Car', NULL, 'D', 30, 'ai', '2025-10-16 23:35:16', '2025-10-17 09:01:55'),
(14, 1, 2, 'GRADE 2', 'ENGLISH', 'What is the opposite of \'good\'?', 'Bad', 'Great', 'Nice', 'Happy', NULL, 'A', 30, 'ai', '2025-10-16 23:35:16', '2025-10-17 09:01:55'),
(15, 1, 2, 'GRADE 2', 'ENGLISH', 'Which word has the \'th\' sound?', 'Sun', 'That', 'Hat', 'Fun', NULL, 'B', 30, 'ai', '2025-10-16 23:35:16', '2025-10-17 09:01:55'),
(16, 1, 2, 'GRADE 2', 'ENGLISH', 'What is a synonym for \'fast\'?', 'Slow', 'Quick', 'Speedy', 'Rapid', NULL, 'B', 30, 'ai', '2025-10-16 23:35:16', '2025-10-17 09:01:55'),
(17, 1, 2, 'GRADE 2', 'ENGLISH', 'What is the past tense of \'run\'?', 'Running', 'Rinning', 'Ran', 'Runned', NULL, 'C', 30, 'ai', '2025-10-16 23:35:16', '2025-10-17 09:01:55'),
(18, 1, 2, 'GRADE 2', 'ENGLISH', 'Which word means the opposite of \'old\'?', 'Young', 'Ancient', 'New', 'Aged', NULL, 'C', 30, 'ai', '2025-10-16 23:35:16', '2025-10-17 09:01:55'),
(21, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What is a computer?', 'A type of fruit', 'An electronic device that processes data', 'A type of book', 'A type of animal', NULL, 'B', 1800, 'ai', '2025-11-14 14:55:08', '2025-11-14 14:55:08'),
(20, 1, 2, 'GRADE 2', 'ENGLISH', '<p>Which word does not belong in the group?</p>', 'Red', 'Blue', 'Banana', 'Green', NULL, 'C', 30, 'ai', '2025-10-16 23:35:16', '2025-10-17 09:01:55'),
(22, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What is the main purpose of a computer?', 'To play games', 'To make phone calls', 'To process data', 'To make ice cream', NULL, 'C', 1800, 'ai', '2025-11-14 14:55:08', '2025-11-14 14:55:08'),
(23, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What is the name of the screen that you look at on a computer?', 'Mouse', 'Keyboard', 'Monitor', 'Printer', NULL, 'C', 1800, 'ai', '2025-11-14 14:55:08', '2025-11-14 14:55:08'),
(24, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'Which device do you use to move the cursor on the screen?', 'Keyboard', 'Monitor', 'Mouse', 'Printer', NULL, 'C', 1800, 'ai', '2025-11-14 14:55:08', '2025-11-14 14:55:08'),
(25, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What do you use to input text into a computer?', 'Mouse', 'Keyboard', 'Monitor', 'Printer', NULL, 'B', 1800, 'ai', '2025-11-14 14:55:08', '2025-11-14 14:55:08'),
(26, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'Which of the following stores all the information you type into a computer?', 'Keyboard', 'Mouse', 'Monitor', 'Hard drive', NULL, 'D', 1800, 'ai', '2025-11-14 14:55:08', '2025-11-14 14:55:08'),
(27, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What is the term for the physical components of a computer?', 'Hardware', 'Software', 'Keyboard', 'Printer', NULL, 'A', 1800, 'ai', '2025-11-14 14:55:08', '2025-11-14 14:55:08'),
(28, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What is the term for the programs that run on a computer?', 'Hardware', 'Software', 'Keyboard', 'Printer', NULL, 'B', 1800, 'ai', '2025-11-14 14:55:08', '2025-11-14 14:55:08'),
(29, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'Which of the following is NOT an input device?', 'Keyboard', 'Mouse', 'Printer', 'Microphone', NULL, 'C', 1800, 'ai', '2025-11-14 14:55:08', '2025-11-14 14:55:08'),
(30, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'Which of the following is an output device?', 'Keyboard', 'Mouse', 'Printer', 'Microphone', NULL, 'C', 1800, 'ai', '2025-11-14 14:55:08', '2025-11-14 14:55:08'),
(31, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What is the button that you use to turn a computer on called?', 'Start button', 'Power button', 'Stop button', 'Restart button', NULL, 'B', 1800, 'ai', '2025-11-14 14:55:08', '2025-11-14 14:55:08'),
(32, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'Which of the following is NOT a type of computer?', 'Laptop', 'Tablet', 'Hammer', 'Desktop', NULL, 'C', 1800, 'ai', '2025-11-14 14:55:08', '2025-11-14 14:55:08'),
(33, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What is the primary color of the letters on a typical computer keyboard?', 'Blue', 'Red', 'Black', 'Green', NULL, 'C', 1800, 'ai', '2025-11-14 14:55:08', '2025-11-14 14:55:08'),
(34, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What does the mouse do on a computer?', 'It allows you to type', 'It moves the cursor on the screen', 'It displays images', 'It prints documents', NULL, 'B', 1800, 'ai', '2025-11-14 14:55:08', '2025-11-14 14:55:08'),
(35, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What is the purpose of a printer?', 'To listen to music', 'To display images', 'To print documents', 'To play games', NULL, 'C', 1800, 'ai', '2025-11-14 14:55:08', '2025-11-14 14:55:08'),
(36, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What is the name of the bar at the bottom of the screen with icons on it?', 'Taskbar', 'Sidebar', 'Menu bar', 'Status bar', NULL, 'A', 1800, 'ai', '2025-11-14 14:55:08', '2025-11-14 14:55:08'),
(37, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'Which of the following is NOT a web browser?', 'Google Chrome', 'Safari', 'Microsoft Word', 'Mozilla Firefox', NULL, 'C', 1800, 'ai', '2025-11-14 14:55:08', '2025-11-14 14:55:08'),
(38, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What is the term for a collection of information on a computer?', 'Folder', 'Book', 'Game', 'Drawing', NULL, 'A', 1800, 'ai', '2025-11-14 14:55:08', '2025-11-14 14:55:08'),
(39, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What is the internet?', 'A type of food', 'A global network of computers', 'A type of car', 'A type of animal', NULL, 'B', 1800, 'ai', '2025-11-14 14:55:08', '2025-11-14 14:55:08'),
(40, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What do you use to navigate to different websites on the internet?', 'Monitor', 'Mouse', 'Web browser', 'Keyboard', NULL, 'C', 1800, 'ai', '2025-11-14 14:55:08', '2025-11-14 14:55:08'),
(41, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'Which of the following is NOT a social media platform?', 'Facebook', 'Instagram', 'Microsoft Word', 'Twitter', NULL, 'C', 1800, 'ai', '2025-11-14 14:55:08', '2025-11-14 14:55:08'),
(42, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What is the term for when a computer freezes and stops working?', 'Freeze', 'Crash', 'Stop', 'Go', NULL, 'B', 1800, 'ai', '2025-11-14 14:55:08', '2025-11-14 14:55:08'),
(43, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What is the main purpose of a computer mouse?', 'To eat cheese', 'To move the cursor on the screen', 'To take pictures', 'To make phone calls', NULL, 'B', 1800, 'ai', '2025-11-14 14:55:08', '2025-11-14 14:55:08'),
(44, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What do you click on to open a program on a computer?', 'Start button', 'Mouse', 'Icon', 'Keyboard', NULL, 'C', 1800, 'ai', '2025-11-14 14:55:08', '2025-11-14 14:55:08'),
(45, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What is the name of the search engine owned by Google?', 'Bing', 'Yahoo', 'Google', 'Ask', NULL, 'C', 1800, 'ai', '2025-11-14 14:55:08', '2025-11-14 14:55:08'),
(46, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What is the term for a small picture on the screen that represents a program or file?', 'Icon', 'Mouse', 'Folder', 'Keyboard', NULL, 'A', 1800, 'ai', '2025-11-14 14:55:08', '2025-11-14 14:55:08'),
(47, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What does the space bar do on a keyboard?', 'Moves the cursor', 'Types a space', 'Starts a program', 'Stops a program', NULL, 'B', 1800, 'ai', '2025-11-14 14:55:08', '2025-11-14 14:55:08'),
(48, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What is the term for the text displayed at the very top of a window on the screen?', 'Footer', 'Header', 'Title bar', 'Menu bar', NULL, 'C', 1800, 'ai', '2025-11-14 14:55:08', '2025-11-14 14:55:08'),
(49, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'Which key is used to capitalize letters on the keyboard?', 'Space bar', 'Shift key', 'Enter key', 'Backspace key', NULL, 'B', 1800, 'ai', '2025-11-14 14:55:08', '2025-11-14 14:55:08'),
(50, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What is the term for the arrangement of keys on a keyboard?', 'Layout', 'Design', 'Style', 'Shape', NULL, 'A', 1800, 'ai', '2025-11-14 14:55:08', '2025-11-14 14:55:08'),
(51, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What is the primary purpose of a computer?', 'To play video games', 'To watch movies', 'To calculate and process data', 'To read books', NULL, 'C', 1800, 'ai', '2025-11-14 18:27:10', '2025-11-14 18:27:10'),
(52, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'Which device is used to input information into a computer?', 'Monitor', 'Keyboard', 'Printer', 'Mouse', NULL, 'B', 1800, 'ai', '2025-11-14 18:27:10', '2025-11-14 18:27:10'),
(53, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What does CPU stand for?', 'Computer Processing Unit', 'Central Processing Unit', 'Computer Programming Unit', 'Central Programming Unit', NULL, 'B', 1800, 'ai', '2025-11-14 18:27:10', '2025-11-14 18:27:10'),
(54, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'Which of the following is considered an output device?', 'Keyboard', 'Mouse', 'Speaker', 'Scanner', NULL, 'C', 1800, 'ai', '2025-11-14 18:27:10', '2025-11-14 18:27:10'),
(55, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What button do you press to turn on a computer?', 'Ctrl', 'Shift', 'Power', 'Esc', NULL, 'C', 1800, 'ai', '2025-11-14 18:27:10', '2025-11-14 18:27:10'),
(56, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What do we call small pictures on the computer screen that represent programs?', 'Folders', 'Icons', 'Buttons', 'Links', NULL, 'B', 1800, 'ai', '2025-11-14 18:27:10', '2025-11-14 18:27:10'),
(57, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'Which program is used to create documents, such as letters or reports?', 'Internet browser', 'Email', 'Microsoft Word', 'Powerpoint', NULL, 'C', 1800, 'ai', '2025-11-14 18:27:10', '2025-11-14 18:27:10'),
(58, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What is a software program that spreads from one computer to another and disrupts normal computer operations?', 'Virus', 'Mouse', 'Keyboard', 'Monitor', NULL, 'A', 1800, 'ai', '2025-11-14 18:27:10', '2025-11-14 18:27:10'),
(59, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'Which key do you use to capitalize letters on a keyboard?', 'Tab', 'Caps Lock', 'Shift', 'Enter', NULL, 'C', 1800, 'ai', '2025-11-14 18:27:10', '2025-11-14 18:27:10'),
(60, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'Which of the following is an example of a storage device?', 'Monitor', 'Printer', 'USB flash drive', 'Microphone', NULL, 'C', 1800, 'ai', '2025-11-14 18:27:10', '2025-11-14 18:27:10'),
(61, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What is the purpose of a web browser?', 'To create documents', 'To play video games', 'To browse the internet', 'To listen to music', NULL, 'C', 1800, 'ai', '2025-11-14 18:27:10', '2025-11-14 18:27:10'),
(62, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'Which of the following is a social media platform?', 'Google', 'Facebook', 'Microsoft', 'Adobe', NULL, 'B', 1800, 'ai', '2025-11-14 18:27:10', '2025-11-14 18:27:10'),
(63, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What kind of device is a computer monitor?', 'Input', 'Output', 'External', 'Internal', NULL, 'B', 1800, 'ai', '2025-11-14 18:27:10', '2025-11-14 18:27:10'),
(64, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'Which key is used to delete characters to the right of the cursor on a keyboard?', 'Delete', 'Backspace', 'Enter', 'Shift', NULL, 'A', 1800, 'ai', '2025-11-14 18:27:10', '2025-11-14 18:27:10'),
(65, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What does the acronym URL stand for?', 'Uniform Resource Locator', 'Universal Resource Language', 'Unique Resource Link', 'Ultimate Resource Locator', NULL, 'A', 1800, 'ai', '2025-11-14 18:27:10', '2025-11-14 18:27:10'),
(66, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'Which program is used to create and organize data in rows and columns?', 'Microsoft Word', 'Excel', 'Powerpoint', 'Outlook', NULL, 'B', 1800, 'ai', '2025-11-14 18:27:10', '2025-11-14 18:27:10'),
(67, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What is the name of the bar at the bottom of the computer screen that shows open programs?', 'Taskbar', 'Menu bar', 'Status bar', 'Title bar', NULL, 'A', 1800, 'ai', '2025-11-14 18:27:10', '2025-11-14 18:27:10'),
(68, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'Which key do you use to confirm an entry on a keyboard?', 'Shift', 'Enter', 'Tab', 'Caps Lock', NULL, 'B', 1800, 'ai', '2025-11-14 18:27:10', '2025-11-14 18:27:10'),
(69, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'Which program is used for sending and receiving electronic messages?', 'Word', 'Excel', 'Email', 'Powerpoint', NULL, 'C', 1800, 'ai', '2025-11-14 18:27:10', '2025-11-14 18:27:10'),
(70, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What is the purpose of a firewall on a computer?', 'To protect against viruses', 'To control the temperature of the computer', 'To play music', 'To adjust screen brightness', NULL, 'A', 1800, 'ai', '2025-11-14 18:27:10', '2025-11-14 18:27:10'),
(71, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'Which device is used to move the cursor on the computer screen?', 'Monitor', 'Keyboard', 'Mouse', 'Printer', NULL, 'C', 1800, 'ai', '2025-11-14 18:27:10', '2025-11-14 18:27:10'),
(72, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What is the purpose of a search engine?', 'To watch movies', 'To play video games', 'To search and find information on the internet', 'To create documents', NULL, 'C', 1800, 'ai', '2025-11-14 18:27:10', '2025-11-14 18:27:10'),
(73, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'Which of the following is an example of a file format?', 'Microsoft', 'Excel', 'MP3', 'URL', NULL, 'C', 1800, 'ai', '2025-11-14 18:27:10', '2025-11-14 18:27:10'),
(74, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What do we call the main storage area in the computer where data is stored permanently?', 'Mouse', 'RAM', 'ROM', 'Hard drive', NULL, 'D', 1800, 'ai', '2025-11-14 18:27:10', '2025-11-14 18:27:10'),
(75, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What do we call the intersection of a row and a column on a spreadsheet?', 'Box', 'Square', 'Cell', 'Circle', NULL, 'C', 1800, 'ai', '2025-11-14 18:27:10', '2025-11-14 18:27:10'),
(76, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'Which of the following is used to connect a computer to the internet?', 'Ethernet cable', 'USB flash drive', 'Microphone', 'Monitor', NULL, 'A', 1800, 'ai', '2025-11-14 18:27:10', '2025-11-14 18:27:10'),
(77, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What is the purpose of a software update?', 'To slow down the computer', 'To add new features or fix bugs', 'To increase the cost of the computer', 'To reduce security', NULL, 'B', 1800, 'ai', '2025-11-14 18:27:10', '2025-11-14 18:27:10'),
(78, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'Which key is used to complete a command on a keyboard?', 'Shift', 'Enter', 'Tab', 'Caps Lock', NULL, 'B', 1800, 'ai', '2025-11-14 18:27:10', '2025-11-14 18:27:10'),
(79, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'What do we call a website address, such as www.google.com?', 'Link', 'Bookmark', 'URL', 'Search Engine', NULL, 'C', 1800, 'ai', '2025-11-14 18:27:10', '2025-11-14 18:27:10'),
(80, 1, 3, 'GRADE 2', 'COMPUTER STUDIES', 'Which of the following is a programming language?', 'Microsoft', 'Google', 'Java', 'Amazon', NULL, 'C', 1800, 'ai', '2025-11-14 18:27:10', '2025-11-14 18:27:10'),
(81, 1, 4, 'GRADE 2', 'HISTORY', 'Who was the first President of the United States?', 'Thomas Jefferson', 'George Washington', 'Abraham Lincoln', 'John Adams', NULL, 'B', 1800, 'ai', '2025-11-14 18:33:04', '2025-11-14 18:33:04'),
(82, 1, 4, 'GRADE 2', 'HISTORY', 'What event started the American Revolutionary War?', 'The Boston Tea Party', 'The signing of the Declaration of Independence', 'The Battle of Yorktown', 'The Winter at Valley Forge', NULL, 'A', 1800, 'ai', '2025-11-14 18:33:04', '2025-11-14 18:33:04'),
(83, 1, 4, 'GRADE 2', 'HISTORY', 'Who discovered America in 1492?', 'Christopher Columbus', 'Marco Polo', 'Hernan Cortes', 'Vasco da Gama', NULL, 'A', 1800, 'ai', '2025-11-14 18:33:04', '2025-11-14 18:33:04'),
(84, 1, 4, 'GRADE 2', 'HISTORY', 'Who was the first woman to fly solo across the Atlantic Ocean?', 'Amelia Earhart', 'Sally Ride', 'Bessie Coleman', 'Harriet Quimby', NULL, 'A', 1800, 'ai', '2025-11-14 18:33:04', '2025-11-14 18:33:04'),
(85, 1, 4, 'GRADE 2', 'HISTORY', 'What ancient civilization built the pyramids?', 'Chinese', 'Mayans', 'Egyptians', 'Greeks', NULL, 'C', 1800, 'ai', '2025-11-14 18:33:04', '2025-11-14 18:33:04'),
(86, 1, 4, 'GRADE 2', 'HISTORY', 'Who was the leader of the Civil Rights Movement in the United States?', 'Martin Luther King Jr.', 'Rosa Parks', 'Harriet Tubman', 'Malcolm X', NULL, 'A', 1800, 'ai', '2025-11-14 18:33:04', '2025-11-14 18:33:04'),
(87, 1, 4, 'GRADE 2', 'HISTORY', 'Which country was the first to put a human on the moon?', 'Russia', 'Germany', 'United States', 'China', NULL, 'C', 1800, 'ai', '2025-11-14 18:33:04', '2025-11-14 18:33:04'),
(88, 1, 4, 'GRADE 2', 'HISTORY', 'The Great Wall of China was built to protect against invasions from which group?', 'Mongols', 'Vikings', 'Romans', 'Egyptians', NULL, 'A', 1800, 'ai', '2025-11-14 18:33:04', '2025-11-14 18:33:04'),
(89, 1, 4, 'GRADE 2', 'HISTORY', 'Who is known as the \"Father of the United States\"?', 'George Washington', 'Abraham Lincoln', 'Thomas Jefferson', 'Benjamin Franklin', NULL, 'A', 1800, 'ai', '2025-11-14 18:33:04', '2025-11-14 18:33:04'),
(90, 1, 4, 'GRADE 2', 'HISTORY', 'What year did World War II end?', '1941', '1945', '1949', '1955', NULL, 'B', 1800, 'ai', '2025-11-14 18:33:04', '2025-11-14 18:33:04'),
(91, 1, 4, 'GRADE 2', 'HISTORY', 'What is the name of the ship that brought the Pilgrims to America in 1620?', 'The Mayflower', 'The Santa Maria', 'The Nina', 'The Pinta', NULL, 'A', 1800, 'ai', '2025-11-14 18:33:04', '2025-11-14 18:33:04'),
(92, 1, 4, 'GRADE 2', 'HISTORY', 'Which famous African American leader fought for civil rights in South Africa?', 'Nelson Mandela', 'Frederick Douglass', 'Malcolm X', 'Harriet Tubman', NULL, 'A', 1800, 'ai', '2025-11-14 18:33:04', '2025-11-14 18:33:04'),
(93, 1, 4, 'GRADE 2', 'HISTORY', 'Where did the Industrial Revolution begin?', 'United States', 'France', 'England', 'China', NULL, 'C', 1800, 'ai', '2025-11-14 18:33:04', '2025-11-14 18:33:04'),
(94, 1, 4, 'GRADE 2', 'HISTORY', 'Who painted the Mona Lisa?', 'Pablo Picasso', 'Leonardo da Vinci', 'Vincent van Gogh', 'Michelangelo', NULL, 'B', 1800, 'ai', '2025-11-14 18:33:04', '2025-11-14 18:33:04'),
(95, 1, 4, 'GRADE 2', 'HISTORY', 'In what year did the Titanic sink?', '1900', '1912', '1923', '1934', NULL, 'B', 1800, 'ai', '2025-11-14 18:33:04', '2025-11-14 18:33:04'),
(96, 1, 4, 'GRADE 2', 'HISTORY', 'Who was the first woman to win a Nobel Prize?', 'Marie Curie', 'Mother Teresa', 'Amelia Earhart', 'Jane Goodall', NULL, 'A', 1800, 'ai', '2025-11-14 18:33:04', '2025-11-14 18:33:04'),
(97, 1, 4, 'GRADE 2', 'HISTORY', 'Who wrote the Declaration of Independence?', 'Thomas Jefferson', 'George Washington', 'Benjamin Franklin', 'John Adams', NULL, 'A', 1800, 'ai', '2025-11-14 18:33:04', '2025-11-14 18:33:04'),
(98, 1, 4, 'GRADE 2', 'HISTORY', 'What ancient civilization built the Colosseum in Rome?', 'Greeks', 'Egyptians', 'Romans', 'Mayans', NULL, 'C', 1800, 'ai', '2025-11-14 18:33:04', '2025-11-14 18:33:04'),
(99, 1, 4, 'GRADE 2', 'HISTORY', 'What year did the American Civil War start?', '1860', '1875', '1855', '1865', NULL, 'A', 1800, 'ai', '2025-11-14 18:33:04', '2025-11-14 18:33:04'),
(100, 1, 4, 'GRADE 2', 'HISTORY', 'What ancient civilization built the Sphinx in Egypt?', 'Chinese', 'Mayans', 'Egyptians', 'Greeks', NULL, 'C', 1800, 'ai', '2025-11-14 18:33:04', '2025-11-14 18:33:04'),
(101, 1, 4, 'GRADE 2', 'HISTORY', 'Who was the first female Prime Minister of Great Britain?', 'Margaret Thatcher', 'Queen Elizabeth I', 'Angela Merkel', 'Golda Meir', NULL, 'A', 1800, 'ai', '2025-11-14 18:33:04', '2025-11-14 18:33:04'),
(102, 1, 4, 'GRADE 2', 'HISTORY', 'What year did the Wright brothers make the first successful powered flight?', '1892', '1903', '1912', '1920', NULL, 'B', 1800, 'ai', '2025-11-14 18:33:04', '2025-11-14 18:33:04'),
(103, 1, 4, 'GRADE 2', 'HISTORY', 'Who invented the telephone?', 'Alexander Graham Bell', 'Thomas Edison', 'Nikola Tesla', 'Samuel Morse', NULL, 'A', 1800, 'ai', '2025-11-14 18:33:04', '2025-11-14 18:33:04'),
(104, 1, 4, 'GRADE 2', 'HISTORY', 'What ancient civilization built Machu Picchu in Peru?', 'Aztec', 'Inca', 'Olmec', 'Incas', NULL, 'B', 1800, 'ai', '2025-11-14 18:33:04', '2025-11-14 18:33:04'),
(105, 1, 4, 'GRADE 2', 'HISTORY', 'Who was the first President of Mexico?', 'Benito Juarez', 'Pancho Villa', 'Miguel Hidalgo', 'Antonio López de Santa Anna', NULL, 'A', 1800, 'ai', '2025-11-14 18:33:04', '2025-11-14 18:33:04'),
(106, 1, 4, 'GRADE 2', 'HISTORY', 'What year did the Great Depression begin?', '1925', '1929', '1932', '1937', NULL, 'B', 1800, 'ai', '2025-11-14 18:33:04', '2025-11-14 18:33:04'),
(107, 1, 4, 'GRADE 2', 'HISTORY', 'Who was the last pharaoh of Ancient Egypt?', 'Tutankhamun', 'Cleopatra', 'Ramses II', 'Nefertiti', NULL, 'B', 1800, 'ai', '2025-11-14 18:33:04', '2025-11-14 18:33:04'),
(108, 1, 4, 'GRADE 2', 'HISTORY', 'What year did the Berlin Wall fall?', '1985', '1989', '1991', '1995', NULL, 'B', 1800, 'ai', '2025-11-14 18:33:04', '2025-11-14 18:33:04'),
(109, 1, 4, 'GRADE 2', 'HISTORY', 'Who was the first female astronaut in space?', 'Sally Ride', 'Valentina Tereshkova', 'Mae Jemison', 'Judith Resnik', NULL, 'B', 1800, 'ai', '2025-11-14 18:33:04', '2025-11-14 18:33:04'),
(110, 1, 4, 'GRADE 2', 'HISTORY', 'What year was the Declaration of Independence signed?', '1773', '1776', '1787', '1790', NULL, 'B', 1800, 'ai', '2025-11-14 18:33:04', '2025-11-14 18:33:04'),
(111, 1, 5, 'GRADE 2', 'NATIONAL VALUE', 'What is the basic unit of society?', 'Family', 'School', 'Church', 'Hospital', NULL, 'A', 1800, 'ai', '2025-11-14 19:14:32', '2025-11-14 19:14:32'),
(112, 1, 5, 'GRADE 2', 'NATIONAL VALUE', 'Which of the following is not a social responsibility?', 'Attending school regularly', 'Helping with household chores', 'Taking care of pets', 'Ignoring others in need', NULL, 'D', 1800, 'ai', '2025-11-14 19:14:32', '2025-11-14 19:14:32'),
(113, 1, 5, 'GRADE 2', 'NATIONAL VALUE', 'Which class of food provides the body with energy?', 'Protein', 'Carbohydrates', 'Vitamins', 'Minerals', NULL, 'B', 1800, 'ai', '2025-11-14 19:14:32', '2025-11-14 19:14:32'),
(114, 1, 5, 'GRADE 2', 'NATIONAL VALUE', 'Which type of security is important for protecting your home?', 'Financial security', 'Emotional security', 'Physical security', 'Social security', NULL, 'C', 1800, 'ai', '2025-11-14 19:14:32', '2025-11-14 19:14:32'),
(115, 1, 5, 'GRADE 2', 'NATIONAL VALUE', 'What is the capital city of Lagos State, Nigeria?', 'Lagos City', 'Abuja', 'Ibadan', 'Kano', NULL, 'A', 1800, 'ai', '2025-11-14 19:14:32', '2025-11-14 19:14:32'),
(116, 1, 5, 'GRADE 2', 'NATIONAL VALUE', 'Who is responsible for protecting and providing for the family?', 'Parents', 'Friends', 'Teachers', 'Strangers', NULL, 'A', 1800, 'ai', '2025-11-14 19:14:32', '2025-11-14 19:14:32'),
(117, 1, 5, 'GRADE 2', 'NATIONAL VALUE', 'What is the purpose of marriage?', 'To have children', 'To have a party', 'To have pets', 'To have fun', NULL, 'A', 1800, 'ai', '2025-11-14 19:14:32', '2025-11-14 19:14:32'),
(118, 1, 5, 'GRADE 2', 'NATIONAL VALUE', 'Which type of security is important for protecting your identity online?', 'Financial security', 'Emotional security', 'Cyber security', 'National security', NULL, 'C', 1800, 'ai', '2025-11-14 19:14:32', '2025-11-14 19:14:32'),
(119, 1, 5, 'GRADE 2', 'NATIONAL VALUE', 'Which type of food helps in building and repairing body tissues?', 'Carbohydrates', 'Proteins', 'Fats', 'Sugars', NULL, 'B', 1800, 'ai', '2025-11-14 19:14:32', '2025-11-14 19:14:32'),
(120, 1, 5, 'GRADE 2', 'NATIONAL VALUE', 'What is the importance of respecting elders in society?', 'Elders are always right', 'Elders have more experience', 'Elders are stronger', 'Elders are younger', NULL, 'B', 1800, 'ai', '2025-11-14 19:14:32', '2025-11-14 19:14:32'),
(121, 1, 5, 'GRADE 2', 'NATIONAL VALUE', 'Which class of food helps in the healthy functioning of the brain?', 'Carbohydrates', 'Proteins', 'Fats', 'Sugars', NULL, 'A', 1800, 'ai', '2025-11-14 19:14:32', '2025-11-14 19:14:32'),
(122, 1, 5, 'GRADE 2', 'NATIONAL VALUE', 'What is the role of a community in society?', 'To divide people', 'To unite people', 'To create conflict', 'To spread rumors', NULL, 'B', 1800, 'ai', '2025-11-14 19:14:32', '2025-11-14 19:14:32'),
(123, 1, 5, 'GRADE 2', 'NATIONAL VALUE', 'Which type of security is important for protecting the environment?', 'Financial security', 'Emotional security', 'Environmental security', 'Social security', NULL, 'C', 1800, 'ai', '2025-11-14 19:14:32', '2025-11-14 19:14:32'),
(124, 1, 5, 'GRADE 2', 'NATIONAL VALUE', 'What is the importance of religion in society?', 'To promote division', 'To promote peace and harmony', 'To promote violence', 'To promote hatred', NULL, 'B', 1800, 'ai', '2025-11-14 19:14:32', '2025-11-14 19:14:32'),
(125, 1, 5, 'GRADE 2', 'NATIONAL VALUE', 'Which type of food helps in maintaining healthy skin and hair?', 'Carbohydrates', 'Proteins', 'Fats', 'Sugars', NULL, 'C', 1800, 'ai', '2025-11-14 19:14:32', '2025-11-14 19:14:32'),
(126, 1, 5, 'GRADE 2', 'NATIONAL VALUE', 'What is the role of a teacher in society?', 'To educate students', 'To entertain students', 'To punish students', 'To ignore students', NULL, 'A', 1800, 'ai', '2025-11-14 19:14:32', '2025-11-14 19:14:32'),
(127, 1, 5, 'GRADE 2', 'NATIONAL VALUE', 'What is the significance of a neighborhood in society?', 'To create barriers', 'To promote isolation', 'To foster community spirit', 'To promote violence', NULL, 'C', 1800, 'ai', '2025-11-14 19:14:32', '2025-11-14 19:14:32'),
(128, 1, 5, 'GRADE 2', 'NATIONAL VALUE', 'Which type of security is important for protecting your health?', 'Financial security', 'Emotional security', 'Physical security', 'Social security', NULL, 'C', 1800, 'ai', '2025-11-14 19:14:32', '2025-11-14 19:14:32'),
(129, 1, 5, 'GRADE 2', 'NATIONAL VALUE', 'What is the importance of social responsibilities in society?', 'To ignore others', 'To promote selfishness', 'To contribute to the well-being of others', 'To spread rumors', NULL, 'C', 1800, 'ai', '2025-11-14 19:14:32', '2025-11-14 19:14:32'),
(130, 1, 5, 'GRADE 2', 'NATIONAL VALUE', 'Who is responsible for shaping the values and beliefs of a child?', 'Parents', 'Friends', 'Strangers', 'Teachers', NULL, 'A', 1800, 'ai', '2025-11-14 19:14:32', '2025-11-14 19:14:32'),
(131, 1, 6, 'GRADE 2', 'CIVIC EDUCATION', 'Who are the leaders in the community that help make decisions and maintain peace?', 'Teachers', 'Community Leaders', 'Students', 'Police Officers', NULL, 'B', 30, 'ai', '2025-11-26 17:53:48', '2025-11-26 17:53:48'),
(132, 1, 6, 'GRADE 2', 'CIVIC EDUCATION', 'Why are rules and laws important in a community?', 'To make people feel sad', 'To maintain peace and order', 'To stop people from having fun', 'To create more noise', NULL, 'B', 30, 'ai', '2025-11-26 17:53:48', '2025-11-26 17:53:48'),
(133, 1, 6, 'GRADE 2', 'CIVIC EDUCATION', 'What are values?', 'Things that are not important', 'Beliefs that guide how we act', 'Colors that are pretty', 'Games we play', NULL, 'B', 30, 'ai', '2025-11-26 17:53:48', '2025-11-26 17:53:48'),
(134, 1, 6, 'GRADE 2', 'CIVIC EDUCATION', 'What is the meaning of citizenship?', 'Belonging to a country and having rights and responsibilities', 'Living in a different country', 'Traveling around the world', 'Attending school', NULL, 'A', 30, 'ai', '2025-11-26 17:53:48', '2025-11-26 17:53:48'),
(135, 1, 6, 'GRADE 2', 'CIVIC EDUCATION', 'How can we promote national consciousness?', 'By playing games', 'By ignoring our country', 'By celebrating our culture and respecting one another', 'By staying indoors', NULL, 'C', 30, 'ai', '2025-11-26 17:53:48', '2025-11-26 17:53:48'),
(136, 1, 6, 'GRADE 2', 'CIVIC EDUCATION', 'What is responsible parenthood?', 'Ignoring children', 'Taking care of children and teaching them right from wrong', 'Letting children do anything', 'Not caring about children', NULL, 'B', 30, 'ai', '2025-11-26 17:53:48', '2025-11-26 17:53:48'),
(137, 1, 6, 'GRADE 2', 'CIVIC EDUCATION', 'Why is it important to follow traffic rules?', 'To make traffic worse', 'To keep people safe on roads', 'To make cars go faster', 'To make driving more difficult', NULL, 'B', 30, 'ai', '2025-11-26 17:53:48', '2025-11-26 17:53:48'),
(138, 1, 6, 'GRADE 2', 'CIVIC EDUCATION', 'What is a good way to resolve conflicts with friends?', 'By shouting', 'By ignoring them', 'By talking and listening to each other', 'By getting angry', NULL, 'C', 30, 'ai', '2025-11-26 17:53:48', '2025-11-26 17:53:48'),
(139, 1, 6, 'GRADE 2', 'CIVIC EDUCATION', 'What should you do in case of an emergency?', 'Run away', 'Stay calm and ask for help', 'Hide', 'Ignore the situation', NULL, 'B', 30, 'ai', '2025-11-26 17:53:48', '2025-11-26 17:53:48'),
(140, 1, 6, 'GRADE 2', 'CIVIC EDUCATION', 'What does drug abuse mean?', 'Using medicine correctly', 'Misusing drugs for the wrong reasons', 'Taking food supplements', 'Drinking water', NULL, 'B', 30, 'ai', '2025-11-26 17:53:48', '2025-11-26 17:53:48'),
(141, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'Which of the following is important for sustainable human relation in a society?', 'Tolerance', 'Birth registration', 'Cultural affinity', 'Rehabilitation', NULL, 'A', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(142, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'The machinery through which the will of the state is driven is described as', 'Administration', 'Rule of law', 'Government', 'Custom and tradition', NULL, 'C', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(143, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'A major attribute an individual will likely exhibit if not contented is', 'Jealousy', 'Irresponsibility', 'Greediness', 'Dishonesty', NULL, 'C', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(144, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'Standards, rules and criteria that determine acceptable norms that influence a cordial relationship in the society are referred to as', 'Values', 'Attitudes', 'Conventions', 'Regulations', NULL, 'A', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(145, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'Under the Nigeria 1999 constitution as amended, the right to secede is', 'Allowed to any state in the federation', 'Denied all states in the federation', 'Resident in local government in the federation', 'Given to the federal government', NULL, 'B', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(146, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'The Nigerian Tribune newspaper was established by', 'Herbert Macauley', 'Obafemi Awolowo', 'Anthony Enahoro', 'Ahmadu Bello', NULL, 'A', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(147, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'A person born in Ghana by Nigerian parents and resides in Ghana is a citizen of', 'Ghana by naturalization', 'Nigeria by birth', 'Nigeria by registration', 'Ghana by birth', NULL, 'B', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(148, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'The payment of residential utility bills is a duty of the', 'Federal government', 'State government', 'Local government', 'Citizens', NULL, 'D', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(149, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'An inalienable right enjoyed by citizens of a state but denied all non-citizens is the right to', 'Fair hearing', 'Freedom of speech', 'Be voted for', 'Sue and be sued', NULL, 'C', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(150, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'Right to ownership of property falls under the category of', 'Civil right', 'Social right', 'Political right', 'Economic right', NULL, 'D', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(151, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'The right to freedom of expression can be limited by', 'The legislature', 'The police', 'Slander', 'Insecurity', NULL, 'C', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(152, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'Human rights abuse can be prevented with the existence of', 'Independent judiciary', 'Well-equipped police force', 'Strong armed forces', 'Strong intergovernmental relation', NULL, 'A', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(153, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'To enhance national development, parenthood, which is the nucleus of every society, must be', 'Regulated by religious clerics', 'Relaxed in their responsibilities', 'Supported by leaders in government', 'A civil and morally responsible one', NULL, 'D', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(154, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'The beam of yellow colour on a traffic light is an indication to drivers to', 'Move', 'Get ready to move', 'Stop', 'Watch out for cars', NULL, 'B', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(155, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'Road signs are usually', 'Regulatory and informative', 'Persuasive and regulatory', 'Informative and persuasive', 'Punitive and informative', NULL, 'A', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(156, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'From the above statement, it is clear that accidents can be', 'Discouraged', 'Managed', 'Eliminated', 'Prevented', NULL, 'D', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(157, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'Traffic regulations are laws that mainly', 'Guide all road users on safety practices', 'Establish agencies for control of traffic', 'Ensure the teaching of road safety in school', 'Instruct drivers on the use of traffic signs only', NULL, 'A', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(158, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'Positive interpersonal relationship mainly promotes', 'Competition with one another', 'Peaceful co-existence', 'Existence of healthy rivalry', 'Acquisition of business ideas', NULL, 'B', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(159, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'A social affiliation between two or more people in the society is known as', 'Intercommunal relations', 'Inter-ethnic relations', 'Interpersonal relations', 'Inter-societal relations', NULL, 'C', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(160, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'A major achievement that can be attributed to good intercommunal relationship in Nigeria is', 'Curtailing rural-urban migration', 'Promoting national cultural festivals', 'Encouraging competition among individuals in the society', 'Promoting peace, mutual understanding, and development', NULL, 'D', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(161, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'Activities of secret cults are not likely to be prominent in', 'Educational campuses', 'Motor parks', 'Market squares', 'Religious gatherings', NULL, 'D', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(162, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'Which of the following factors have made political apathy in Nigeria more pronounced?', 'Long period of dictatorship and election rigging', 'Poverty, ethnicity, and religious fanaticism', 'Indiscriminate registration of parties and illiteracy', 'Use of card readers and complexity of voting procedure', NULL, 'A', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(163, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'Combating human trafficking requires the efforts of', 'Government, educational bodies, religious organizations excluding civil societies', 'Government and non-governmental agencies excluding the students', 'International bodies, pressure groups, and other non-governmental agencies only', 'Individuals, government, non-governmental agencies including international bodies', NULL, 'D', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(164, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'When voters exercise their right to vote based on monetary or material inducements, the elected candidates may suffer', 'Eroded legitimacy during the elected term', 'Loss of voters\' support in the next election', 'Loss of party support for another term', 'Erosion of the dividends of democracy', NULL, 'A', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(165, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'Political apathy can be addressed by', 'Selling of votes to the highest bidders', 'Criticizing the policies of elected officials', 'Boycotting election campaigns and rallies', 'Public enlightenment and campaigns', NULL, 'D', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(166, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'The legislative arm of government can check the executive by', 'Withholding the salaries of ministers', 'Delaying the posting of ambassadors', 'Demanding the review of any act of the executive', 'Reporting them to the Supreme Court', NULL, 'C', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(167, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'The Nigerian federation is divided into how many geopolitical zones?', '774', '36', '6', '4', NULL, 'C', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(168, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'The executive, legislative, and judiciary constitute the', 'Areas of government', 'Systems of government', 'Tiers of government', 'Forms of government', NULL, 'C', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(169, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'Civil societies act mainly as a link between', 'Government and international bodies', 'Different opposing communities', 'Individuals of divergent interests', 'Government and the populace', NULL, 'D', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(170, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'When power is concentrated in one central government, the constitution is said to be', 'Federal', 'Unitary', 'Republican', 'Semi-federal', NULL, 'B', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(171, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'Legislations on issues affecting policies on money, policing, and international relations are within the scope of', 'Exclusive legislative matters', 'Concurrent and residual list', 'Residual legislative matters', 'Concurrent and exclusive list', NULL, 'A', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(172, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'God-fatherism in a democratic system of government can lead to', 'Neglect of followers', 'Citizen’s participation', 'Loss of employment', 'Economic development', NULL, 'A', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(173, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'One significance of democracy in Nigeria is that it promotes', 'Secularism', 'Sectionalism', 'Regionalism', 'Constitutionalism', NULL, 'D', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(174, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'Execution and implementation of government policies are parts of the functions of the', 'Military', 'Civil society', 'Legislature', 'Public service', NULL, 'D', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(175, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'One of the political responsibilities of a citizen is', 'Exercising the right of franchise', 'Participating in social gatherings', 'Engaging in cultural debates', 'Joining town hall meetings', NULL, 'A', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(176, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'Local government administration promotes', 'Consensus building in governance', 'Responsible government', 'Democracy at the grassroots', 'Responsive government', NULL, 'C', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(177, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'The traffic sign indicated in Figure 1 means', 'No waiting', 'No stopping', 'No crossing', 'No overtaking', NULL, 'B', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(178, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'Where you will likely not find the sign in Figure 1 in Nigeria is', 'Court areas', 'Military zone', 'Presidential villa', 'Shopping malls', NULL, 'D', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(179, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'The major aim of youth empowerment programmes is to', 'Tackle the problem of insecurity and lawlessness', 'Provide vocational skills to the youths', 'Provide attitudinal reorientation to the youths', 'Help the youth become good decision-makers', NULL, 'B', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(180, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'Human trafficking can be described as', 'Desperate desire by youths to travel abroad for greener pasture', 'Exploitation of humans in a way their rights are deprived in the course of movement', 'Exploration and adventures in foreign countries', 'Recruitment of youths as casual workers in distant places', NULL, 'B', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(181, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'Traffic regulations are mainly meant for all', 'Pedestrians', 'Road users', 'Truck drivers', 'Private drivers', NULL, 'B', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(182, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'When opposing communities come together to discuss a way out of a pending feud, the action is best described as', 'Co-operation', 'Dialogue', 'Arbitration', 'Peacekeeping', NULL, 'B', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(183, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'Authority that is recognized by the law of the land is called', 'Religious authority', 'Consultative authority', 'Constituted authority', 'Charismatic authority', NULL, 'C', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(184, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'Which of the following values will likely cause harm to society?', 'Tolerance', 'Indiscipline', 'Politeness', 'Fair play', NULL, 'B', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(185, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'The major reasons some countries are termed developing resulted from', 'III and VI', 'IV and V', 'II and VII', 'V and VI', NULL, 'B', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(186, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'Non-negotiable entitlements of every individual on earth are', 'II and V', 'II and VII', 'VI and VII', 'III and VI', NULL, 'C', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(187, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'From the list above, the two experiences of individuals that require counseling are', 'III and V', 'I and VII', 'II and III', 'I and IV', NULL, 'D', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(188, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'The major reasons for citizens\' reorientation in civic education are', 'II and V', 'III and V', 'VI and VII', 'I and II', NULL, 'B', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(189, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'The search of a citizen’s residence by the police without a warrant or court order amounts to breach of his/her right to', 'Privacy', 'Freedom of conscience', 'Freedom of expression', 'Life', NULL, 'A', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35'),
(190, 1, 7, 'SSS 3', 'CIVIC EDUCATION', 'The unpleasant attitudes toward people living with HIV/AIDS is termed', 'Playing safe', 'Civic neglect', 'Human rights abuse', 'Stigmatization', NULL, 'D', 2400, 'ai', '2025-11-26 19:26:35', '2025-11-26 19:26:35');

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

DROP TABLE IF EXISTS `answers`;
CREATE TABLE IF NOT EXISTS `answers` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `question_id` int NOT NULL,
  `answer` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_correct` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`id`, `question_id`, `answer`, `is_correct`, `created_at`, `updated_at`) VALUES
(1, 1, 'Any person, animal, place or thing', 1, '2025-10-16 22:09:18', '2025-10-16 22:09:18'),
(2, 1, 'Name of people', 0, '2025-10-16 22:09:18', '2025-10-16 22:09:18'),
(3, 1, 'Name of animals only', 0, '2025-10-16 22:09:18', '2025-10-16 22:09:18'),
(4, 1, 'Name of places only', 0, '2025-10-16 22:09:18', '2025-10-16 22:09:18');

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

DROP TABLE IF EXISTS `classes`;
CREATE TABLE IF NOT EXISTS `classes` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`id`, `name`, `created_at`, `updated_at`) VALUES
(2, 'GRADE 1', '2025-10-16 17:39:32', '2025-10-16 17:39:32'),
(3, 'GRADE 2', '2025-10-16 17:39:38', '2025-10-16 17:39:38'),
(4, 'GRADE 3', '2025-10-16 17:39:44', '2025-10-16 17:39:44'),
(5, 'GRADE 4', '2025-10-16 17:39:50', '2025-10-16 17:39:50'),
(6, 'GRADE 5', '2025-10-16 17:39:56', '2025-10-16 17:39:56'),
(8, 'SSS 3', '2025-11-26 19:18:19', '2025-11-26 19:18:19');

-- --------------------------------------------------------

--
-- Table structure for table `curriculums`
--

DROP TABLE IF EXISTS `curriculums`;
CREATE TABLE IF NOT EXISTS `curriculums` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `curriculum_id` bigint UNSIGNED DEFAULT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `class` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `time_left` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `curriculums_user_id_foreign` (`user_id`),
  KEY `curriculums_curriculum_id_foreign` (`curriculum_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `curriculums`
--

INSERT INTO `curriculums` (`id`, `curriculum_id`, `user_id`, `name`, `subject`, `class`, `time_left`, `content`, `created_at`, `updated_at`) VALUES
(2, 2, 1, 'ENGLISH', 'ENGLISH', 'GRADE 2', '30', 'Generate question based on the following topics:\nAntonyms and synonyms\nNoun and Verb\nAdjective and pronoun\nSingular and Plural\nSounds and rhymes', '2025-10-16 23:16:00', '2025-10-17 08:58:10'),
(3, 3, 1, 'Computer Studies', 'COMPUTER STUDIES', 'GRADE 2', '30', 'Generate questions that cover computer fundamentals, input and output devices\r\nApplication development\r\nprogramming Language\r\nDatabase and structure', '2025-11-14 14:54:36', '2025-11-14 14:54:36'),
(4, 4, 1, 'History', 'HISTORY', 'GRADE 2', '30', 'Generate History Questions on Nigerian Independent\r\nIndigenous people of Lagos\r\nNational heroes in Nigeria\r\nGeo political zone in nigeria\r\nwho was the first premier of western region\r\nNationalism\r\nMajor tribes in nigeria', '2025-11-14 18:32:02', '2025-11-14 18:32:02'),
(5, 5, 1, 'National Value', 'NATIONAL VALUE', 'GRADE 2', '30', 'Family\r\nMarriage\r\nReligion\r\nSocial Responsibilities\r\nClasses of food\r\nTypes of security\r\nNeighborhood\r\nStranger', '2025-11-14 19:13:37', '2025-11-14 19:13:37'),
(6, 6, 1, 'Civic Education', 'CIVIC EDUCATION', 'GRADE 2', '30', 'National Consciousness- Community Leaders: Understanding the roles of community leaders, such as traditional leaders (Oba, Eze, Emir/Sarki, etc.)\r\n- Rules in the Community: Importance of rules and laws in maintaining peace and order\r\n\r\nValues and Citizenship- Values: Definition, types, and importance of values in society\r\n- Citizenship: Meaning, goals, and duties of citizenship\r\n- Nationalism: Ways to promote national consciousness, integrity, and unity\r\n\r\nResponsible Citizenship- Responsible Parenthood: Meaning, roles, and importance in national development\r\n- Traffic Regulations: Importance of traffic rules and regulations\r\n- Inter-Personal Relationships: Skills for promoting interpersonal relationships and resolving conflicts\r\n\r\nSafety and Security- Security Education: Basic safety measures and emergency procedures\r\n\r\nEmerging Issues- Cultism: Meaning, causes, consequences, and prevention\r\n- Drug Abuse: Meaning, causes, symptoms, and prevention\r\n- HIV/AIDS: Meaning, causes, symptoms, and prevention', '2025-11-25 12:53:02', '2025-11-26 17:25:33'),
(7, 7, 1, 'CIVIC EDUCATION SSS3', 'CIVIC EDUCATION', 'SSS 3', '2400', 'Generate strictly based on the questions here. do not modify, just ensure to add the accurate correct options.\r\nEnsure that every question has the complete questions needed to for students to answer seamlessly. Feel free to correct errors where noticed:\r\n\r\n1.Which of the following is important for sustainable human relation in a society?\r\na.Tolerance\r\nb.Birth registration\r\nc.Cultural affinity\r\nd.Rehabilitation\r\n \r\n2.The machinery through which the will of the state is driven is described as\r\na.Administration\r\nb.Rule of law\r\nc.Government\r\nd.Custom and tradition\r\n \r\n3.A major attribute an individual will likely exhibit if not contented is\r\na.Jealousy\r\nb.Irresponsibility\r\nc.Greediness\r\nd.Dishonesty\r\n \r\n4.Standards, rules and criteria that determine acceptable norms that influence a cordial relationship in the society are referred to as\r\na.Values\r\nb.Attitudes\r\nc.Conventions\r\nd.Regulations\r\n \r\n5.Under the Nigeria 1999 constitution as amended, the right to secede is \r\na.Allowed to any state in the federation\r\nb.Denied all states in the federation\r\nc.Resident in local government in the federation\r\nd.Given to the federal government\r\n \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n6.The Nigerian Tribune newspaper was established by\r\na.Herbert Macauley\r\nb.Obafemi Awolowo\r\nc.Anthony Enahoro\r\nd.Ahamdu Bello\r\n \r\n7.A person born in Ghana by nigerian parents and resides in Ghana is a citizen of\r\na.Ghana by naturalization \r\nb.Nigeria by birth\r\nc.Nigeria by registration\r\nd.Ghana by birth\r\n \r\n8.The payment of residential utility bills is a duty of the\r\na.Federal government\r\nb.State government\r\nc.Local government\r\nd.Citizens\r\n \r\n9.An inalienable right enjoyed by citizens of a state but denied all non-citizens is the right to \r\na.Fair hearing\r\nb.Freedom of speech\r\nc.Be voted for\r\nd.Sure and be sued\r\n \r\n10.Right to ownership of property falls under the category of\r\na.Civil right\r\nb.Social right\r\nc.Political right\r\nd.Economic right\r\n \r\n11.The right to freedom of expression can be limited by\r\n\r\na.The legislature\r\nb.The police\r\nc.Slander\r\nd.Insecurity\r\n \r\n12.Human rights abuse can be prevented with the existence of\r\na.Independent judiciary\r\nb.Well-equipped police force\r\nc.Strong armed forces\r\nd.Strong intergovernmental relation\r\n \r\n13.To enhance national development parenthood which is the nucleus of every society must be\r\na.Regulated by religious cleries\r\nb.Relaxed in their responsibilities\r\nc.Supported by leaders in government\r\nd.A civil and morally responsible one\r\n \r\n14.The beam of yellow colour on a traffic light is an indication to drivers to\r\na.Move\r\nb.Get ready to move\r\nc.Stop \r\nd.Watch out for cars\r\n \r\n15.Road signs are usually\r\na.Regulatory and informative\r\nb.Persuasive and regulatory\r\nc.Informative and persuasive\r\nd.Punitive and informative\r\n \r\nUse the write-up below to answer question 16\r\n\r\nDriving on the highways entails being very watchful, observant and attentive to one’s surrounding, else you may run into an object or someone most accidents are caused by human factors.\r\n\r\n16.From the above statement, it is clear that accidents can be\r\na.Discouraged\r\nb.Managed\r\nc.Eliminated\r\nd.Prevented\r\n\r\n17.Traffic regulations are law that mainly\r\na.Guide all road users on safety practices\r\nb.Establish agencies for control of traffic\r\nc.Ensure the teaching of road safety in school\r\nd.Instruct drivers on the use of traffic signs only\r\n \r\n18.Positive interpersonal relationship mainly promotes\r\na.Competition with one another\r\nb.Peaceful co-existence\r\nc.Existence of healthy rivalry\r\nd.Acquisition of business ideas\r\n \r\n19.A social affiliation between two or more people in the society is known as\r\na.Intercommunal relations\r\nb.Inter-ethnic relations\r\nc.Interpersonal relations\r\nd.Inter societal relations\r\n \r\n20.A major achievement that can be attributed to good intercommunal relationship in Nigeria is\r\na.Curtailing rural-urban migration\r\nb.Promoting national cultural festivals\r\nc.Encouraging competition among individuals in the society\r\nd.Promoting peace mutual understanding and development\r\n \r\n21.Activities of secret cults are not likely to be prominent in\r\na.Educational campuses\r\nb.Motor parks\r\nc.Market squares\r\nd.Religious gatherings\r\n\r\n22.Which of the following factors have made political apathy in Nigeria more pronounced?\r\na.Long period of dictatorship and election rigging\r\nb.Poverty, ethnicity and religious fanaticism\r\nc.Indiscriminate registration of parties and illiteracy\r\nd.Use of card readers and complexity of voting procedure\r\n\r\n23.Combating human trafficking requires the efforts of\r\na.Government, educational bodies, religious organizations excluding civil societies\r\nb.Government and non-governmental agencies excluding the students\r\nc.International bodies, pressure groups and other non-governmental agencies only\r\nd.Individuals, government, non-governmental agencies including international bodies\r\n\r\n24.When voters exercise their right to vote based on monetary or material inducements, the elected candidates may suffer\r\na.Eroded legitimacy during elected tem\r\nb.Loss of voters support in the next election\r\nc.Loss of party support for another term\r\nd.Erosion of dividends of democracy\r\n\r\n25.Political apathy can be addressed by\r\na.Selling of votes of the highest bidders\r\nb.Criticizing the policies of elected officials\r\nc.Boycotting election campaigns and rallies\r\nd.Public enlightenment and campaigns\r\n \r\n26.Legislative are of government can check the executive by\r\na.Withholding the salaries of minister\r\nb.Delaying the posting of ambassadors\r\nc.Demanding the review of any act of the executive\r\nd.Reporting them to the Supreme Court\r\n \r\n27.The Nigerian federation is divided into how many geopolitical zones?\r\na.774\r\nb.36\r\nc.6\r\nd.4\r\n \r\n28.The executive, legislative and judiciary constitute the\r\na.Ares of government\r\nb.Systems of government\r\nc.Tiers of government \r\nd.Forms of government\r\n \r\n29.Civil societies act mainly as a link between\r\na.Government and international bodies\r\nb.Different opposing communities\r\nc.Individuals of divergent interests\r\nd.Government and the populace\r\n \r\n30.When power is concentrated in one central government, the constitution is said to be\r\na.Federal\r\nb.Unitary\r\nc.Republican\r\nd.Semi-federal\r\n \r\n31.Legislations on issues affecting policies on money policing and international relations are within the scope of\r\na.Exclusive legislative matter\r\nb.Concurrent and residual list\r\nc.Residual legislative matter\r\nd.Concurrent and exclusive list\r\n \r\n32.God-fatherism in a democratic system of government can lead to\r\na.Neglect of followers\r\nb.Citizen’s participation\r\nc.Loss of employment\r\nd.Economic development\r\n \r\n33.One significance of democracy in Nigeria is the it promotes\r\na.Secularism\r\nb.Sectionalism\r\nc.Regionalism\r\nd.Constitutionalism\r\n \r\n34.Execution and implementation of government policies are parts of the functions of the\r\na.Military\r\nb.Civil society\r\nc.Legislature\r\nd.Public service\r\n \r\n35.One of the political responsibilities of a citizen is\r\na.Exercising the right of franchise\r\nb.Participating in social gatherings\r\nc.Engaging in cultural debates\r\nd.Joining town hall meetings\r\n \r\n36.Local government administration promotes\r\na.Consensus building in governance\r\nb.Responsible government\r\nc.Democracy at the grass roots\r\nd.Responsive government\r\n \r\n37.The traffic sign indicated in Figure 1 means\r\na.No waiting\r\nb.No stopping\r\nc.No crossing\r\nd.No overtaking\r\n \r\n38.Where you will likely not find the sign in Figure 1 in Nigeria is\r\na.Court areas \r\nb.Military zone\r\nc.Presidential villa\r\nd.Shopping malls\r\n \r\n39.The major aim of youth empowerment programmes is to \r\na.Tackle the problem of insecurity and lawlessness\r\nb.Provide vocational skills to the youths\r\nc.Provide attitudinal reorientation to the youths\r\nd.Help the youth become good decision makers\r\n \r\n40.Human trafficking can be described as\r\na.Desperate desire by youths to travel abroad for greener pasture\r\nb.Exploitation of humans in way their rights are deprived in the course of movement\r\nc.Exploration and adventures in foreign countries\r\nd.Recruitment of youths as casual workers in distant place\r\n \r\n41.Traffic regulations are mainly meant for all\r\na.Pedestrians\r\nb.Road users\r\nc.Truck drivers\r\nd.Private drivers\r\n \r\n42. When opposing communities come together, to discuss a way out of a pending feud, the action in best described as\r\na.Co-operation\r\nb.Dialogue\r\nc.Arbitration\r\nd.Peacekeeping\r\n \r\n43.Authority that is recognized by the law of the land is called\r\na.Religious authority\r\nb.Consultative authority\r\nc.Constituted authority\r\nd.Charismatic authority\r\n \r\n44.Which of the following values will likely, cause harm to the society?\r\na.Tolerance\r\nb.Indiscipline\r\nc.Politeness\r\nd.Fair play\r\n \r\nCarefully study the following list of civic education terms / to VII below and use them to answer questions 45 to 48.\r\n\r\nHIV/AIDS\r\nLaw and order\r\nPolitical apathy\r\nHuman trafficking\r\nPopular participation\r\nResponsible parenting\r\nFundamental human rights\r\n\r\n45.The major reasons some countries are termed developing resulted from\r\na.III and VI\r\nb.IV and V\r\nc.II and VII\r\nd.V and VI\r\n \r\n46.Non-negotiable entitlements of every individual on earth are\r\na.II and V\r\nb.II and VII\r\nc.VI and VII\r\nd.III and VI\r\n \r\n47.From the list above, the two experiences of individuals that require counselling are\r\na.III and V\r\nb.I and VII\r\nc.II and III\r\nd.I and IV\r\n \r\n48.The major reasons for citizens reorientation in civic education are\r\na.II and V\r\nb.III and V\r\nc.VI and VII\r\nd.I and II\r\n\r\n49.The search of a citizen’s residence by the police without a warrant or court order amounts to breach of his/her right to\r\na.Privacy\r\nb.Freedom of conscience\r\nc.Freedom of expression\r\nd.Life\r\n \r\n50.The unpleasant attitudes toward people living with HIV/AIDS is termed\r\na.Playing safe\r\nb.Civic neglect\r\nc.Human right abuse\r\nd.Stigmatization', '2025-11-26 19:25:11', '2025-11-26 19:25:11');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
CREATE TABLE IF NOT EXISTS `jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `queue` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint UNSIGNED NOT NULL,
  `reserved_at` int UNSIGNED DEFAULT NULL,
  `available_at` int UNSIGNED NOT NULL,
  `created_at` int UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2022_02_06_194236_create_results_table', 1),
(6, '2022_02_06_194254_create_answers_table', 1),
(7, '2022_02_06_194323_create_quizzes_table', 1),
(8, '2022_02_06_194336_create_questions_table', 1),
(9, '2022_02_11_221112_create_quiz_user_table', 1),
(10, '2025_03_05_195932_create_jobs_table', 1),
(11, '2025_06_02_185135_create_ai_questions_table', 1),
(12, '2025_06_02_185141_create_teacher_questions_table', 1),
(13, '2025_06_02_185148_create_test_sessions_table', 1),
(14, '2025_06_02_202918_create_student_answers_table', 1),
(15, '2025_06_02_205003_create_curriculums_table', 1),
(16, '2025_10_16_173634_create_class_models_table', 2),
(17, '2025_10_16_173742_create_subjects_table', 2),
(18, '2025_10_16_185549_create_school_infos_table', 3),
(19, '2025_10_16_215657_create_quizzes_table', 4),
(20, '2025_10_16_235159_create_quiz_users_table', 5),
(21, '2025_11_13_084145_add_curriculum_id_to_curriculums_table', 6),
(22, '2025_11_13_172657_add_curriculum_id_to_quizzes_table', 7),
(23, '2025_11_13_184833_add_class_division_to_users_table', 8),
(24, '2025_11_13_200139_add_started_fields_to_quiz_user_table', 9),
(25, '2025_11_13_204217_fix_quiz_users_columns', 10),
(26, '2025_11_14_134107_add_quiz_id_to_student_answers_table', 11),
(27, '2025_11_14_135824_add_default_question_type_to_student_answers_table', 12),
(28, '2025_11_14_142929_add_curriculum_id_to_quiz_users_table', 13);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
CREATE TABLE IF NOT EXISTS `questions` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `question` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quiz_id` int NOT NULL,
  `mfile_ext` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `question`, `quiz_id`, `mfile_ext`, `created_at`, `updated_at`) VALUES
(1, '<p>What is a noun?</p>', 1, '', '2025-10-16 22:09:18', '2025-10-16 22:09:18');

-- --------------------------------------------------------

--
-- Table structure for table `quizzes`
--

DROP TABLE IF EXISTS `quizzes`;
CREATE TABLE IF NOT EXISTS `quizzes` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `curriculum_id` bigint UNSIGNED DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `class_id` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_id` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `sessions` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `terms` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `minutes` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `quizzes_curriculum_id_foreign` (`curriculum_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `quizzes`
--

INSERT INTO `quizzes` (`id`, `curriculum_id`, `name`, `description`, `class_id`, `subject_id`, `sessions`, `terms`, `status`, `minutes`, `created_at`, `updated_at`) VALUES
(1, 2, 'ENGLISH', 'English Language 30 Question', 'GRADE 2', 'ENGLISH', '2025/2026', 'First Term', '0', 30, '2025-10-16 21:22:15', '2025-10-16 21:22:15'),
(2, 3, 'PHYSICS', 'Matter', 'GRADE 2', 'COMPUTER STUDIES', '2025/2026', 'First Term', '1', 30, '2025-11-14 14:57:34', '2025-11-14 14:57:34'),
(3, 4, 'History', 'Generate History Questions on Nigerian Independent\r\nIndigenous people of Lagos\r\nNational heroes in Nigeria\r\nGeo political zone in nigeria\r\nwho was the first premier of western region\r\nNationalism\r\nMajor tribes in nigeria', 'GRADE 2', 'HISTORY', '1', '1', '0', 30, '2025-11-14 18:32:02', '2025-11-14 18:32:02'),
(4, 5, 'National Value', 'Family\r\nMarriage\r\nReligion\r\nSocial Responsibilities\r\nClasses of food\r\nTypes of security\r\nNeighborhood\r\nStranger', 'GRADE 2', 'NATIONAL VALUE', '1', '1', '0', 30, '2025-11-14 19:13:37', '2025-11-14 19:13:37'),
(5, 6, 'Civic Education', 'National Consciousness- Community Leaders: Understanding the roles of community leaders, such as traditional leaders (Oba, Eze, Emir/Sarki, etc.)\r\n- Rules in the Community: Importance of rules and laws in maintaining peace and order\r\n\r\nValues and Citizenship- Values: Definition, types, and importance of values in society\r\n- Citizenship: Meaning, goals, and duties of citizenship\r\n- Nationalism: Ways to promote national consciousness, integrity, and unity\r\n\r\nResponsible Citizenship- Responsible Parenthood: Meaning, roles, and importance in national development\r\n- Traffic Regulations: Importance of traffic rules and regulations\r\n- Inter-Personal Relationships: Skills for promoting interpersonal relationships and resolving conflicts\r\n\r\nSafety and Security- Security Education: Basic safety measures and emergency procedures\r\n\r\nEmerging Issues- Cultism: Meaning, causes, consequences, and prevention\r\n- Drug Abuse: Meaning, causes, symptoms, and prevention\r\n- HIV/AIDS: Meaning, causes, symptoms, and prevention', 'GRADE 2', 'CIVIC EDUCATION', '1', '1', '0', 20, '2025-11-25 12:53:02', '2025-11-25 12:53:02'),
(6, 7, 'CIVIC EDUCATION SSS3', 'Generate strictly based on the questions here. do not modify, just ensure to add the accurate correct options.\r\nEnsure that every question has the complete questions needed to for students to answer seamlessly. Feel free to correct errors where noticed:\r\n\r\n1.Which of the following is important for sustainable human relation in a society?\r\na.Tolerance\r\nb.Birth registration\r\nc.Cultural affinity\r\nd.Rehabilitation\r\n \r\n2.The machinery through which the will of the state is driven is described as\r\na.Administration\r\nb.Rule of law\r\nc.Government\r\nd.Custom and tradition\r\n \r\n3.A major attribute an individual will likely exhibit if not contented is\r\na.Jealousy\r\nb.Irresponsibility\r\nc.Greediness\r\nd.Dishonesty\r\n \r\n4.Standards, rules and criteria that determine acceptable norms that influence a cordial relationship in the society are referred to as\r\na.Values\r\nb.Attitudes\r\nc.Conventions\r\nd.Regulations\r\n \r\n5.Under the Nigeria 1999 constitution as amended, the right to secede is \r\na.Allowed to any state in the federation\r\nb.Denied all states in the federation\r\nc.Resident in local government in the federation\r\nd.Given to the federal government\r\n \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n6.The Nigerian Tribune newspaper was established by\r\na.Herbert Macauley\r\nb.Obafemi Awolowo\r\nc.Anthony Enahoro\r\nd.Ahamdu Bello\r\n \r\n7.A person born in Ghana by nigerian parents and resides in Ghana is a citizen of\r\na.Ghana by naturalization \r\nb.Nigeria by birth\r\nc.Nigeria by registration\r\nd.Ghana by birth\r\n \r\n8.The payment of residential utility bills is a duty of the\r\na.Federal government\r\nb.State government\r\nc.Local government\r\nd.Citizens\r\n \r\n9.An inalienable right enjoyed by citizens of a state but denied all non-citizens is the right to \r\na.Fair hearing\r\nb.Freedom of speech\r\nc.Be voted for\r\nd.Sure and be sued\r\n \r\n10.Right to ownership of property falls under the category of\r\na.Civil right\r\nb.Social right\r\nc.Political right\r\nd.Economic right\r\n \r\n11.The right to freedom of expression can be limited by\r\n\r\na.The legislature\r\nb.The police\r\nc.Slander\r\nd.Insecurity\r\n \r\n12.Human rights abuse can be prevented with the existence of\r\na.Independent judiciary\r\nb.Well-equipped police force\r\nc.Strong armed forces\r\nd.Strong intergovernmental relation\r\n \r\n13.To enhance national development parenthood which is the nucleus of every society must be\r\na.Regulated by religious cleries\r\nb.Relaxed in their responsibilities\r\nc.Supported by leaders in government\r\nd.A civil and morally responsible one\r\n \r\n14.The beam of yellow colour on a traffic light is an indication to drivers to\r\na.Move\r\nb.Get ready to move\r\nc.Stop \r\nd.Watch out for cars\r\n \r\n15.Road signs are usually\r\na.Regulatory and informative\r\nb.Persuasive and regulatory\r\nc.Informative and persuasive\r\nd.Punitive and informative\r\n \r\nUse the write-up below to answer question 16\r\n\r\nDriving on the highways entails being very watchful, observant and attentive to one’s surrounding, else you may run into an object or someone most accidents are caused by human factors.\r\n\r\n16.From the above statement, it is clear that accidents can be\r\na.Discouraged\r\nb.Managed\r\nc.Eliminated\r\nd.Prevented\r\n\r\n17.Traffic regulations are law that mainly\r\na.Guide all road users on safety practices\r\nb.Establish agencies for control of traffic\r\nc.Ensure the teaching of road safety in school\r\nd.Instruct drivers on the use of traffic signs only\r\n \r\n18.Positive interpersonal relationship mainly promotes\r\na.Competition with one another\r\nb.Peaceful co-existence\r\nc.Existence of healthy rivalry\r\nd.Acquisition of business ideas\r\n \r\n19.A social affiliation between two or more people in the society is known as\r\na.Intercommunal relations\r\nb.Inter-ethnic relations\r\nc.Interpersonal relations\r\nd.Inter societal relations\r\n \r\n20.A major achievement that can be attributed to good intercommunal relationship in Nigeria is\r\na.Curtailing rural-urban migration\r\nb.Promoting national cultural festivals\r\nc.Encouraging competition among individuals in the society\r\nd.Promoting peace mutual understanding and development\r\n \r\n21.Activities of secret cults are not likely to be prominent in\r\na.Educational campuses\r\nb.Motor parks\r\nc.Market squares\r\nd.Religious gatherings\r\n\r\n22.Which of the following factors have made political apathy in Nigeria more pronounced?\r\na.Long period of dictatorship and election rigging\r\nb.Poverty, ethnicity and religious fanaticism\r\nc.Indiscriminate registration of parties and illiteracy\r\nd.Use of card readers and complexity of voting procedure\r\n\r\n23.Combating human trafficking requires the efforts of\r\na.Government, educational bodies, religious organizations excluding civil societies\r\nb.Government and non-governmental agencies excluding the students\r\nc.International bodies, pressure groups and other non-governmental agencies only\r\nd.Individuals, government, non-governmental agencies including international bodies\r\n\r\n24.When voters exercise their right to vote based on monetary or material inducements, the elected candidates may suffer\r\na.Eroded legitimacy during elected tem\r\nb.Loss of voters support in the next election\r\nc.Loss of party support for another term\r\nd.Erosion of dividends of democracy\r\n\r\n25.Political apathy can be addressed by\r\na.Selling of votes of the highest bidders\r\nb.Criticizing the policies of elected officials\r\nc.Boycotting election campaigns and rallies\r\nd.Public enlightenment and campaigns\r\n \r\n26.Legislative are of government can check the executive by\r\na.Withholding the salaries of minister\r\nb.Delaying the posting of ambassadors\r\nc.Demanding the review of any act of the executive\r\nd.Reporting them to the Supreme Court\r\n \r\n27.The Nigerian federation is divided into how many geopolitical zones?\r\na.774\r\nb.36\r\nc.6\r\nd.4\r\n \r\n28.The executive, legislative and judiciary constitute the\r\na.Ares of government\r\nb.Systems of government\r\nc.Tiers of government \r\nd.Forms of government\r\n \r\n29.Civil societies act mainly as a link between\r\na.Government and international bodies\r\nb.Different opposing communities\r\nc.Individuals of divergent interests\r\nd.Government and the populace\r\n \r\n30.When power is concentrated in one central government, the constitution is said to be\r\na.Federal\r\nb.Unitary\r\nc.Republican\r\nd.Semi-federal\r\n \r\n31.Legislations on issues affecting policies on money policing and international relations are within the scope of\r\na.Exclusive legislative matter\r\nb.Concurrent and residual list\r\nc.Residual legislative matter\r\nd.Concurrent and exclusive list\r\n \r\n32.God-fatherism in a democratic system of government can lead to\r\na.Neglect of followers\r\nb.Citizen’s participation\r\nc.Loss of employment\r\nd.Economic development\r\n \r\n33.One significance of democracy in Nigeria is the it promotes\r\na.Secularism\r\nb.Sectionalism\r\nc.Regionalism\r\nd.Constitutionalism\r\n \r\n34.Execution and implementation of government policies are parts of the functions of the\r\na.Military\r\nb.Civil society\r\nc.Legislature\r\nd.Public service\r\n \r\n35.One of the political responsibilities of a citizen is\r\na.Exercising the right of franchise\r\nb.Participating in social gatherings\r\nc.Engaging in cultural debates\r\nd.Joining town hall meetings\r\n \r\n36.Local government administration promotes\r\na.Consensus building in governance\r\nb.Responsible government\r\nc.Democracy at the grass roots\r\nd.Responsive government\r\n \r\n37.The traffic sign indicated in Figure 1 means\r\na.No waiting\r\nb.No stopping\r\nc.No crossing\r\nd.No overtaking\r\n \r\n38.Where you will likely not find the sign in Figure 1 in Nigeria is\r\na.Court areas \r\nb.Military zone\r\nc.Presidential villa\r\nd.Shopping malls\r\n \r\n39.The major aim of youth empowerment programmes is to \r\na.Tackle the problem of insecurity and lawlessness\r\nb.Provide vocational skills to the youths\r\nc.Provide attitudinal reorientation to the youths\r\nd.Help the youth become good decision makers\r\n \r\n40.Human trafficking can be described as\r\na.Desperate desire by youths to travel abroad for greener pasture\r\nb.Exploitation of humans in way their rights are deprived in the course of movement\r\nc.Exploration and adventures in foreign countries\r\nd.Recruitment of youths as casual workers in distant place\r\n \r\n41.Traffic regulations are mainly meant for all\r\na.Pedestrians\r\nb.Road users\r\nc.Truck drivers\r\nd.Private drivers\r\n \r\n42. When opposing communities come together, to discuss a way out of a pending feud, the action in best described as\r\na.Co-operation\r\nb.Dialogue\r\nc.Arbitration\r\nd.Peacekeeping\r\n \r\n43.Authority that is recognized by the law of the land is called\r\na.Religious authority\r\nb.Consultative authority\r\nc.Constituted authority\r\nd.Charismatic authority\r\n \r\n44.Which of the following values will likely, cause harm to the society?\r\na.Tolerance\r\nb.Indiscipline\r\nc.Politeness\r\nd.Fair play\r\n \r\nCarefully study the following list of civic education terms / to VII below and use them to answer questions 45 to 48.\r\n\r\nHIV/AIDS\r\nLaw and order\r\nPolitical apathy\r\nHuman trafficking\r\nPopular participation\r\nResponsible parenting\r\nFundamental human rights\r\n\r\n45.The major reasons some countries are termed developing resulted from\r\na.III and VI\r\nb.IV and V\r\nc.II and VII\r\nd.V and VI\r\n \r\n46.Non-negotiable entitlements of every individual on earth are\r\na.II and V\r\nb.II and VII\r\nc.VI and VII\r\nd.III and VI\r\n \r\n47.From the list above, the two experiences of individuals that require counselling are\r\na.III and V\r\nb.I and VII\r\nc.II and III\r\nd.I and IV\r\n \r\n48.The major reasons for citizens reorientation in civic education are\r\na.II and V\r\nb.III and V\r\nc.VI and VII\r\nd.I and II\r\n\r\n49.The search of a citizen’s residence by the police without a warrant or court order amounts to breach of his/her right to\r\na.Privacy\r\nb.Freedom of conscience\r\nc.Freedom of expression\r\nd.Life\r\n \r\n50.The unpleasant attitudes toward people living with HIV/AIDS is termed\r\na.Playing safe\r\nb.Civic neglect\r\nc.Human right abuse\r\nd.Stigmatization', 'SSS 3', 'CIVIC EDUCATION', '1', '1', '0', 40, '2025-11-26 19:25:11', '2025-11-26 19:25:11');

-- --------------------------------------------------------

--
-- Table structure for table `quiz_users`
--

DROP TABLE IF EXISTS `quiz_users`;
CREATE TABLE IF NOT EXISTS `quiz_users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `curriculum_id` bigint UNSIGNED DEFAULT NULL,
  `quiz_id` int NOT NULL,
  `user_id` int NOT NULL,
  `time_left` bigint DEFAULT NULL,
  `status` tinyint NOT NULL DEFAULT '0',
  `started_at` timestamp NULL DEFAULT NULL,
  `submitted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `quiz_users_curriculum_id_foreign` (`curriculum_id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `quiz_users`
--

INSERT INTO `quiz_users` (`id`, `curriculum_id`, `quiz_id`, `user_id`, `time_left`, `status`, `started_at`, `submitted_at`, `created_at`, `updated_at`) VALUES
(26, 1, 6, 2, 30, 0, NULL, NULL, '2025-11-26 17:25:33', '2025-11-26 17:25:33'),
(31, 2, 1, 3, 0, 2, '2025-11-26 18:59:12', NULL, '2025-11-26 18:59:01', '2025-11-26 19:01:14'),
(15, 4, 3, 2, 30, 0, NULL, NULL, '2025-11-26 14:34:05', '2025-11-26 14:34:05'),
(16, 4, 3, 3, 0, 2, '2025-11-26 15:18:05', NULL, '2025-11-26 14:34:05', '2025-11-26 15:18:55'),
(17, 5, 4, 2, 30, 0, NULL, NULL, '2025-11-26 14:34:27', '2025-11-26 14:34:27'),
(32, 7, 6, 4, 2390, 1, '2025-11-26 19:30:12', NULL, '2025-11-26 19:28:29', '2025-11-26 19:30:23'),
(30, 6, 5, 3, 0, 2, '2025-11-26 18:54:28', NULL, '2025-11-26 18:53:22', '2025-11-26 18:57:10'),
(28, 6, 5, 2, 20, 0, NULL, NULL, '2025-11-26 17:55:45', '2025-11-26 17:55:45');

-- --------------------------------------------------------

--
-- Table structure for table `results`
--

DROP TABLE IF EXISTS `results`;
CREATE TABLE IF NOT EXISTS `results` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `question_id` int NOT NULL,
  `quiz_id` int NOT NULL,
  `answer_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `school_infos`
--

DROP TABLE IF EXISTS `school_infos`;
CREATE TABLE IF NOT EXISTS `school_infos` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `term` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `session` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `school_infos`
--

INSERT INTO `school_infos` (`id`, `name`, `email`, `phone`, `term`, `session`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Yellow Field Fountain Schools', 'schooldrivesng@gmail.com', '09060898687', 'First Term', '2025/2026', '1', '2025-10-16 20:31:18', '2025-10-16 20:31:18');

-- --------------------------------------------------------

--
-- Table structure for table `student_answers`
--

DROP TABLE IF EXISTS `student_answers`;
CREATE TABLE IF NOT EXISTS `student_answers` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `quiz_id` bigint UNSIGNED DEFAULT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `question_id` bigint UNSIGNED NOT NULL,
  `question_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ai',
  `answer_option` char(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_correct` tinyint(1) NOT NULL DEFAULT '0',
  `test_session_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_answers_user_id_foreign` (`user_id`),
  KEY `student_answers_test_session_id_foreign` (`test_session_id`)
) ENGINE=MyISAM AUTO_INCREMENT=230 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `student_answers`
--

INSERT INTO `student_answers` (`id`, `quiz_id`, `user_id`, `question_id`, `question_type`, `answer_option`, `is_correct`, `test_session_id`, `created_at`, `updated_at`) VALUES
(143, 3, 3, 83, 'ai', 'C', 0, 16, '2025-11-26 15:18:18', '2025-11-26 15:18:18'),
(142, 3, 3, 82, 'ai', 'B', 0, 16, '2025-11-26 15:18:18', '2025-11-26 15:18:18'),
(141, 3, 3, 81, 'ai', 'A', 0, 16, '2025-11-26 15:18:18', '2025-11-26 15:18:18'),
(209, 5, 3, 139, 'ai', 'B', 0, 30, '2025-11-26 18:56:51', '2025-11-26 18:56:51'),
(210, 5, 3, 140, 'ai', 'B', 0, 30, '2025-11-26 18:57:09', '2025-11-26 18:57:09'),
(208, 5, 3, 138, 'ai', 'C', 0, 30, '2025-11-26 18:56:51', '2025-11-26 18:56:51'),
(207, 5, 3, 137, 'ai', 'B', 0, 30, '2025-11-26 18:56:51', '2025-11-26 18:56:51'),
(206, 5, 3, 136, 'ai', 'B', 0, 30, '2025-11-26 18:56:04', '2025-11-26 18:56:04'),
(205, 5, 3, 135, 'ai', 'C', 0, 30, '2025-11-26 18:56:04', '2025-11-26 18:56:04'),
(204, 5, 3, 134, 'ai', 'A', 0, 30, '2025-11-26 18:56:04', '2025-11-26 18:56:04'),
(203, 5, 3, 133, 'ai', 'B', 0, 30, '2025-11-26 18:55:29', '2025-11-26 18:55:29'),
(202, 5, 3, 132, 'ai', 'B', 0, 30, '2025-11-26 18:55:29', '2025-11-26 18:55:29'),
(201, 5, 3, 131, 'ai', 'B', 0, 30, '2025-11-26 18:55:29', '2025-11-26 18:55:29'),
(229, 1, 3, 20, 'ai', 'C', 0, 31, '2025-11-26 19:01:14', '2025-11-26 19:01:14'),
(228, 1, 3, 18, 'ai', 'C', 0, 31, '2025-11-26 19:00:59', '2025-11-26 19:00:59'),
(227, 1, 3, 17, 'ai', 'C', 0, 31, '2025-11-26 19:00:59', '2025-11-26 19:00:59'),
(226, 1, 3, 16, 'ai', 'D', 0, 31, '2025-11-26 19:00:59', '2025-11-26 19:00:59'),
(225, 1, 3, 15, 'ai', 'B', 0, 31, '2025-11-26 19:00:49', '2025-11-26 19:00:49'),
(224, 1, 3, 14, 'ai', 'B', 0, 31, '2025-11-26 19:00:49', '2025-11-26 19:00:49'),
(223, 1, 3, 13, 'ai', 'D', 0, 31, '2025-11-26 19:00:49', '2025-11-26 19:00:49'),
(222, 1, 3, 12, 'ai', 'A', 0, 31, '2025-11-26 19:00:29', '2025-11-26 19:00:29'),
(221, 1, 3, 11, 'ai', 'C', 0, 31, '2025-11-26 19:00:29', '2025-11-26 19:00:29'),
(220, 1, 3, 10, 'ai', 'B', 0, 31, '2025-11-26 19:00:29', '2025-11-26 19:00:29'),
(219, 1, 3, 9, 'ai', 'B', 0, 31, '2025-11-26 19:00:11', '2025-11-26 19:00:11'),
(218, 1, 3, 8, 'ai', 'B', 0, 31, '2025-11-26 19:00:11', '2025-11-26 19:00:11'),
(217, 1, 3, 7, 'ai', 'C', 0, 31, '2025-11-26 19:00:11', '2025-11-26 19:00:11'),
(216, 1, 3, 6, 'ai', 'A', 0, 31, '2025-11-26 18:59:48', '2025-11-26 18:59:48'),
(215, 1, 3, 5, 'ai', 'C', 0, 31, '2025-11-26 18:59:48', '2025-11-26 18:59:48'),
(214, 1, 3, 4, 'ai', 'A', 0, 31, '2025-11-26 18:59:48', '2025-11-26 18:59:48'),
(211, 1, 3, 1, 'ai', 'B', 0, 31, '2025-11-26 18:59:32', '2025-11-26 18:59:32'),
(212, 1, 3, 2, 'ai', 'A', 0, 31, '2025-11-26 18:59:32', '2025-11-26 18:59:32'),
(213, 1, 3, 3, 'ai', 'B', 0, 31, '2025-11-26 18:59:32', '2025-11-26 18:59:32');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

DROP TABLE IF EXISTS `subjects`;
CREATE TABLE IF NOT EXISTS `subjects` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `name`, `created_at`, `updated_at`) VALUES
(2, 'ENGLISH', '2025-10-16 17:40:06', '2025-10-16 17:40:06'),
(3, 'MATHEMATICS', '2025-10-16 17:40:14', '2025-10-16 17:40:14'),
(4, 'VERBAL', '2025-10-16 17:40:21', '2025-10-16 17:40:21'),
(5, 'QUANTITATIVE', '2025-10-16 17:40:28', '2025-10-16 17:40:28'),
(6, 'HISTORY', '2025-10-16 17:40:34', '2025-10-16 17:40:34'),
(7, 'NATIONAL VALUE', '2025-10-16 17:40:45', '2025-10-16 17:40:45'),
(9, 'COMPUTER STUDIES', '2025-11-14 14:46:56', '2025-11-14 14:46:56'),
(10, 'CIVIC EDUCATION', '2025-11-25 12:50:46', '2025-11-25 12:50:46');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_questions`
--

DROP TABLE IF EXISTS `teacher_questions`;
CREATE TABLE IF NOT EXISTS `teacher_questions` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint UNSIGNED NOT NULL,
  `class` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `question_text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `option_a` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `option_b` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `option_c` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `option_d` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `option_e` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `correct_option` char(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_ai_generated` tinyint(1) NOT NULL DEFAULT '1',
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `teacher_questions_user_id_foreign` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `test_sessions`
--

DROP TABLE IF EXISTS `test_sessions`;
CREATE TABLE IF NOT EXISTS `test_sessions` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint UNSIGNED NOT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `class` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `num_questions` int NOT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `ended_at` timestamp NULL DEFAULT NULL,
  `score` int NOT NULL DEFAULT '0',
  `time_left` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `test_sessions_user_id_foreign` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `firstname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `class` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `class_division` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `visible_password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Student',
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `term` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `session` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `is_admin` int NOT NULL DEFAULT '2',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `class`, `class_division`, `email`, `password`, `visible_password`, `category`, `phone`, `term`, `session`, `status`, `is_admin`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Patrick', 'Claudius', 'GRADE 2', NULL, 'oludarepatrick@gmail.com', '$2y$10$IqvWjATXWWkJXynK.oGmiONvs4LTGejhxAAGQrLgdP/F3q0fYFW4y', 'Jane@123', 'Staff', '07053796686', 'First Term', '2025/2026', '1', 1, NULL, '2025-10-16 16:29:00', '2025-10-16 16:29:00'),
(2, 'Seven', 'Claudius', 'GRADE 2', 'A', 'jfunmilayoademuyiwa@gmail.com', '$2y$10$EN9aftzNJKlGOlO6ntqmjOHlHROm0rWSpP.tm0fETA55eAgGWzdP2', 'Jane@123', 'Student', '07063415220', 'First Term', '2025/2026', '1', 2, NULL, '2025-10-17 00:13:05', '2025-10-17 00:13:05'),
(3, 'Funmi', 'Oludare', 'GRADE 2', 'A', 'claudiusopatrick@gmail.com', '$2y$10$ddZFfQPrtkCQrpLt2HvJlOi51G3WfSrhoXM7kUEtf70awC8qxIA4S', 'Jane@123', 'Student', '07063415220', 'First Term', '2025/2026', '1', 2, NULL, '2025-10-17 08:39:01', '2025-10-17 08:39:01'),
(4, 'Folarin', 'Ademuyiwa', 'SSS 3', NULL, 'iclaudpat@gmail.com', '$2y$10$ym7N7nxhmjQWORnfM8bQ..ctsdiUoVZlZJpf/AWbK9g7jcOxEnrpS', 'Jane@123', 'Student', '07053796686', 'First Term', '2025/2026', '1', 2, NULL, '2025-11-26 19:03:06', '2025-11-26 19:03:06');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
