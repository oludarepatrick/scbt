<div class="navbar navbar-info navbar-fixed-bottom">
    <div class="navbar-inner1" style="background-color:lightblue !important;">
            <div class="container" style="background-color:darkblue1 !important;">
                <div style="text-align:center; color:darkblue; font-weight: bold;" >
                    <marquee>&copy; <?php echo date('Y'); ?> @ Schooldrive CBT. Allrights Reserved.&nbsp;
                    <span style="color: black">powered by:</span>
                    <a href="#" style="text-decoration: underline; color:black">Drive Technology</a>
                    </marquee>
                </div>
            </div>
    </div>

</div>
<!-- Le javascript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="<?=URL ?>public/js/bootstrap-transition.js"></script>
<script src="<?=URL ?>public/js/bootstrap-alert.js"></script>
<script src="<?=URL ?>public/js/bootstrap-modal.js"></script>
<script src="<?=URL ?>public/js/bootstrap-dropdown.js"></script>
<script src="<?=URL ?>public/js/bootstrap-scrollspy.js"></script>
<script src="<?=URL ?>public/js/bootstrap-tab.js"></script>
<script src="<?=URL ?>public/js/bootstrap-tooltip.js"></script>
<script src="<?=URL ?>public/js/bootstrap-popover.js"></script>
<script src="<?=URL ?>public/js/bootstrap-button.js"></script>
<script src="<?=URL ?>public/js/bootstrap-collapse.js"></script>
<script src="<?=URL ?>public/js/bootstrap-carousel.js"></script>
<script src="<?=URL ?>public/js/bootstrap-typeahead.js"></script>

</body>
</html>
