<div class="container">

    <div class="container-fluid">
        <div class="row-fluid">
            <div class="span8">
                <!--Sidebar content-->
                
                <?php
                    if(!empty($isExamAssigned))
                    {
                        
                        foreach($assignedQuiz as $dd)
                        {
                            $ggdf=$dd['quizId'].'-'.$studId.'-'.$dd['remeningTime'];
                            $qIdStdAtm=base64_encode($ggdf);
                            //echo $qIdStdAtm=$ggdf;
                            echo "<h3>".$dd['class_id']." ".$dd['arm']."</h3>";
                            echo "<table border='1' class='table-strip table-borderd table-hover table-collepsed table-condensed'>";
                            echo "<tr>";
                                echo "<td>Quiz Title:</td>";
                                echo "<td>".$dd['quizName']."</td>";
                            echo "</tr>";
                            echo "<tr>";
                                echo "<td>Subject:</td>";
                                echo "<td>".$dd['subject_id']."</td>";
                            echo "</tr>";
                            echo "<tr>";
                                echo "<td>Total Questions:</td>";
                                echo "<td>".$dd['totalQue']."</td>";
                            echo "</tr>";
                            echo "<tr>";
                                echo "<td>Total Time:</td>";
                                echo "<td>".$dd['minutes']." Minutes</td>";
                            echo "</tr>";

                            if($dd['remeningTime'] > 0)
                            {
                                $dsdCont=($dd['isAtempt']==0?'Start':'Continue');
                                echo "<tr>";
                                    echo "<td colspan='2'><a href='".URL."dashboard/start/".$qIdStdAtm."' class='btn btn-success btn-sm' >".$dsdCont."</a></td>";
                                echo "</tr>";
                            }
                            echo "</table>";
                            
                        }
                        
                    }
                    else{
                        echo "<pre><h4 style='color:red'>No Available Question(s) for now. Check back later</h4></pre>";
                    } 
                ?>
                
                   
            </div>
            <div class="span4">
                <!--Body content-->
                <div   id="sidebar">
                    <div align="center">
                        <img src="<?=URL?>public/img/photo.jpg" class="img-circle" allt="img" style="width:; background-image: url(<?=URL?>public/img/mas.png)" />
                    </div>
                    <div style="font-family:Times New Roman;" align="center"><?php echo $_SESSION['logged_id']['fullname'];  ?></div>
                    <div style="font-family:Times New Roman;" align="center">(<?php echo $_SESSION['logged_id']['email'];  ?>)</div>
                    
                    <br/>
                </div>
            </div>
        </div>

</div> <!-- /container -->
<script type="text/javascript">
    $('.pr').click(function(){

        var a = "#"+this.id; var b = ".v"+this.id;
        var c =$(b).val();

        if(confirm("Are you sure you want start?\n"+c)){
            return true;
        }else{
            return false;
        }});
</script>

