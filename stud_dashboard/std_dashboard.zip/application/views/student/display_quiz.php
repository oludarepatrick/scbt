<?php 
    $i=$startpoint+1;
    echo "<pre><div style='height:450px' class='divScroll'>";
    foreach($queses as $que)
    {
        echo "<div style='font-size: 15px !important; line-height:10px !important' style='magin:margin-button:0px; padding-bottom:0px'>".$que['question']."</div><br/>";
        

        $myOption=1;
        
        echo "<div style='margin:0px; padding:0px'>Option(s)...</div>";
        
        foreach($que['options'] as $optn)
        {
            $checked1=$optn['checken'];
            echo "<div class=>";
            echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type=\"radio\" style='margin-top:10px' name=\"ans\" id='opt".$que['queId'].$myOption."' value='".$val.'-'.$que['queId'].'-'.$optn['answerId']."' class=\"optionsRadios1\" $checked1 />";
            echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong style='padding-top: 15px; font-size:17px'>".$optn['option_desc']."</strong>";
            echo "</div>";
            
            $myOption++;
        }
        $i++;
    }
    echo "</div></pre>";
    
?>
<input type="hidden" class="dte" value="<?php echo $val; ?>">


<script type="text/javascript">

    $('.optionsRadios1').click(function()
    {
        var a = "#"+this.id;
        //alert(a);
        var c =$(a).val();
        //alert(c);
        $.post("<?php echo URL ?>dashboard/save",{c:c},function(data){

            $(a).attr('value',data);

        });

    });

</script>

<script>
    $('.dbtn').click(function(){
        var kk = '<?php echo URL ?>dashboard/questions/'+$(this).attr('href');
        $('.val').load(kk); 
        //alert($(this).attr('href'));
        return false;
    });
</script>