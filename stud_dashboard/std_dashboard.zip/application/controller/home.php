<?php
class Home extends Controller
{
    public function index()
    {
        require 'application/views/home/index.php';
    }

    public function login()
    {
        $reg=$_POST['reg'];
        $login_model = $this->loadModel('LoginModel');
        $logins = $login_model->login($reg);

        $_SESSION['logged_id']=array();
        if(!empty($logins))
        {
            $_SESSION['logged_id'] = array(
                "userId"=>$logins->id,
                "role"=>$logins->is_admin,
                "email"=>$reg,
                "fullname"=>$logins->name,
                "stud_id"=>$logins->stud_id,
                "occupation"=>$logins->occupation,
                "class"=>"SSS ONE"
            );
            //echo $logins->stud_id;
            //echo $_SESSION['logged_id']['stud_id']; exit();
            header("location: ".URL."dashboard/index");
        }
        else{
            echo "<h1>Invalid Login</h1>";
        }
    }

    
}
