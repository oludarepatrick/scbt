<?php
    //session_start();
    class Logout extends Controller
    { 

        public function index()
        {
            unset($_SESSION['logged_id']);
            session_destroy();

            //redirect to home
            header('location: ' . URL . 'home/index');


        }


    }
