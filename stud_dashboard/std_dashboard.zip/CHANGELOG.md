CHANGE LOG
==========

**January 4th 2014**
- fixed htaccess issue when there's a controller named "index" and a base index.php (which collide)

**December 29th 2013**
- fixed case-sensitive model file loading (thanks "grrnikos")
