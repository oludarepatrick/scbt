@include('backend.layouts.navbar')
@include('backend.layouts.sidebar')

    @yield('content')

@include('backend.layouts.footer')