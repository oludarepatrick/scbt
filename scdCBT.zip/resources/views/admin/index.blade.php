
@include('backend.layouts.navbar')
        @include('backend.layouts.sidebar')
            @include('backend.layouts.dashboard')
            @include('backend.layouts.footer')
    