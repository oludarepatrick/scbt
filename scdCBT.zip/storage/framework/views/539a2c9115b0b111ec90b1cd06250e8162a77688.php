<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
       
        <div class="col-md-8">
        <?php if(Session::has('error')): ?>
            <div class="alert alert-danger"><?php echo e(Session::get('error')); ?>

            
            </div>
            <?php endif; ?>
            <div class="card">
           
                <div class="card-header">Dashboard</div>
                <?php if($isExamAssigned): ?>
                <?php $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="card-body">
                <p><h3><?php echo e($quiz->name); ?></h3></p>
                <p>About Exam: <?php echo e($quiz->description); ?></</p>
                <p>Time allocated: <?php echo e($quiz->minutes); ?></p>
                <p>Number of questions: <?php echo e($quiz->questions->count()); ?></p>
                <p>
                    <?php if(!in_array($quiz->id,$wasQuizCompleted)): ?>
                    <a href="user/quiz/<?php echo e($quiz->id); ?>">
                    <button class="btn btn-success">Start Quiz</button>
                    </a>
                    <?php else: ?>
                    <a href="/result/user/<?php echo e(auth()->user()->stud_id); ?>/quiz/<?php echo e($quiz->id); ?>">View Result</a>
                    <span class="float-right" style="margin-left:70px; color:green">Completed</span>
                    <?php endif; ?>
                </p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <p>You have not been assigned any exam</p>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">User Profile</div>
                <div class="card-body">
                <p>Email: <?php echo e(auth()->user()->email); ?></p>
                <p>Occupation: <?php echo e(auth()->user()->occupation); ?></p>
                <p>Address: <?php echo e(auth()->user()->address); ?></p>
                <p>Phone: <?php echo e(auth()->user()->phone); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/schooldr/public_html/drivestores/resources/views/home.blade.php ENDPATH**/ ?>