<?php if(count($subjects)): ?>
    <option value="">--select subjects--</option>  
<?php endif; ?>
<?php $__empty_1 = true; $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <option value="<?php echo e($subject->subject); ?>"><?php echo e($subject->subject); ?></option>  
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <option value="">No Available Subjects</option>  
<?php endif; ?>
<?php /**PATH /home/schooldr/public_html/cbt.schooldrive.com.ng/resources/views/backend/quiz/display-subjects.blade.php ENDPATH**/ ?>