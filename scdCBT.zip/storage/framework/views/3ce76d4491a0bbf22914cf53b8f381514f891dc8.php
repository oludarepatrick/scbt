    <?php $__env->startSection('title','create quiz'); ?>
    
    <?php $__env->startSection('content'); ?>
    <div class="span9">
        <div class="content">
        <?php if(Session::has('message')): ?>

            <div class="alert alert-success"><?php echo e(Session::get('message')); ?></div>
        <?php endif; ?>
        <div class="module">
                <div class="module-head">
                        <h3>All Quiz</h3>
                        </div>
                <div class="module-body">
                <table class="table table-stripped">
                    <thead>
                    <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Minutes</th>
                    <th>Edit</tH>
                    <th>Delete</th>
                    <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if(count($quizzes)>0): ?>
                    <?php $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($key+1); ?></td>
                    <td><?php echo e($quiz->name); ?></td>
                    <td><?php echo e($quiz->description); ?></td>
                    <td><?php echo e($quiz->minutes); ?></td>
                    <td>
                        <a href="<?php echo e(route('quiz.question',[$quiz->id])); ?>"><button class="btn btn-inverse">View Questions</button>
                        </a>
                    </td>
                    <td>
                        <a href="<?php echo e(route('quiz.edit',[$quiz->id])); ?>">
                        <buttom class="btn btn-primary">Edit</buttom>
                        </a>
                    </td>
                  
                   
                        <td>
                        <form id="delete-form<?php echo e($quiz->id); ?>" method="POST" action="<?php echo e(route('quiz.destroy',[$quiz->id])); ?>"><?php echo csrf_field(); ?>
                        <?php echo e(method_field('DELETE')); ?>

                        </form>
                        <a href="#" onclick="if(confirm('Do you want to delete?')){
                            event.preventDefault();
                            document.getElementById('delete-form<?php echo e($quiz->id); ?>').submit()
                        }else{
                            event.preventDefault();
                        }

                        ">
                        <input type="submit" value="Delete" class="btn btn-danger">
                        </a>

                        </td>





                    </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                   <?php else: ?>
                   <td>No Quiz to Display</td>
                   <?php endif; ?>
                    </tbody>
                    </table>
                    </div>
                    </div>
                    </div>
                    </div>
                    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/patrick/quizapp4/resources/views/backend/quiz/index.blade.php ENDPATH**/ ?>