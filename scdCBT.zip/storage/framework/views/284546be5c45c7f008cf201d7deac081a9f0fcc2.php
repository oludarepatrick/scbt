<?php $__env->startSection('content'); ?>
<next-component></next-component>
<h1>Good mornig</h1>
<a href="<?php echo e(route('mycom')); ?>">
                    <button class="btn btn-success">Start Quiz</button>
                    </a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/patrick/quizapp4/resources/views/next.blade.php ENDPATH**/ ?>