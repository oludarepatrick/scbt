<div class="wrapper">
            <div class="container">
                <div class="row">
                    <div class="span3">
                        <div class="sidebar">
                            <ul class="widget widget-menu unstyled">
                                <li class="active"><a href="<?php echo e(url('/')); ?>"><i class="menu-icon icon-dashboard"></i>Dashboard
                                </a></li>
                                <li><a href="<?php echo e(route('quiz.create')); ?>"><i class="menu-icon icon-bullhorn"></i>Create Quiz </a>
                                </li>
                                <li><a href="<?php echo e(route('quiz.index')); ?>"><i class="menu-icon icon-inbox"></i>View Quiz <b class="label green pull-right">
                                    </b> </a></li>
                               
                            </ul>

                            <ul class="widget widget-menu unstyled">
                                <li><a href="<?php echo e(route('question.create')); ?>"><i class="menu-icon icon-bullhorn"></i>Create Question </a>
                                </li>
                                <li><a href="<?php echo e(route('question.index')); ?>"><i class="menu-icon icon-inbox"></i>View Question <b class="label green pull-right">
                                    </b> </a></li>
                               
                            </ul>

                            <ul class="widget widget-menu unstyled">
                                <li><a href="<?php echo e(route('user.create')); ?>"><i class="menu-icon icon-bullhorn"></i>Create User </a>
                                </li>
                                <li><a href="<?php echo e(route('user.index')); ?>"><i class="menu-icon icon-inbox"></i>View Exam <b class="label green pull-right">
                                    </b> </a></li>
                               
                            </ul>

                            <ul class="widget widget-menu unstyled">
                                <li><a href="<?php echo e(route('user.exam')); ?>"><i class="menu-icon icon-bullhorn"></i>Assign Exam </a>
                                </li>
                                <li><a href="<?php echo e(route('view.exam')); ?>"><i class="menu-icon icon-inbox"></i>View User <b class="label green pull-right">
                                    </b> </a></li>
                               
                            </ul>

                            <ul class="widget widget-menu unstyled">
                                <li><a href="<?php echo e(route('result')); ?>"><i class="menu-icon icon-bullhorn"></i>View Result </a>
                                </li>
                               
                               
                            </ul>
                            <!--/.widget-nav-->
                            
                            
                           
                            <!--/.widget-nav-->
                            <ul class="widget widget-menu unstyled">
                                
                                <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"><i class="icon-inbox"></i>
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form></li>
                            </ul>
                        </div>
                        <!--/.sidebar-->
                    </div>
                    <!--/.span3--><?php /**PATH /home/patrick/quizapp4/resources/views/backend/layouts/sidebar.blade.php ENDPATH**/ ?>