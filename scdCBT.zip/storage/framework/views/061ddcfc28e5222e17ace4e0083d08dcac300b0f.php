    <?php $__env->startSection('title','Update Question'); ?>
    
    <?php $__env->startSection('content'); ?>

    <div class="span9">
        <div class="content">

        <?php if(Session::has('message')): ?>

            <div class="alert alert-success"><?php echo e(Session::get('message')); ?></div>
        <?php endif; ?>

        <form action="<?php echo e(route('question.update',[$question->id])); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo e(method_field('PUT')); ?>

            <div class="module">
                <div class="module-head">
                        <h3>Update Question</h3>
                </div>

                <div class="module-body">
                    <div class="control-group">
                    <lable class="control-label" for="question">Choose Quiz</label>
                    <div class="controls">
                    <select name="quiz" class="span8">
                    <option>Select Quiz</option>
                    <?php $__currentLoopData = App\Models\Quiz::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       
                        <option value="<?php echo e($quiz->id); ?>" <?php if($quiz->id==$question->quiz_id): ?>selected <?php endif; ?>><?php echo e($quiz->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                        
                    </div>
                   <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>


                    <div class="control-group">
                    <lable class="control-label" for="question">Question Name</label>
                    <div class="controls">
                        <!--<input type="text" name="question" class="span8" placeholder="question of a quiz" value="<?php echo e($question->question); ?>">-->
                        <textarea id="mceDEMO" name="question" class="span8"><?php echo e($question->question); ?></textarea>
                    </div>
                   <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="control-group">
                        <lable class="control-label" for="question">Upload File(if any)</label>
                        <div class="controls">
                            <input type="file" name="mfile" class="span8" placeholder="Upload file" value="<?php echo e(old('mfile')); ?>">
                        </div>
                        <strong style='color:red; font-size:13px'>file supported type: jpg,png,mp3,mp4,pdf</strong>
                        <?php $__errorArgs = ['mfile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <input type="hidden" value="<?php echo e($question->mfile_ext); ?>" name="old_file"/>
                    <?php if(!empty($question->mfile_ext)): ?>
                        <?php 
                            
                            list($txt,$ext)=explode(".", $question->mfile_ext);
                            $ext=strtolower($ext);
                            
                        ?>
                        <?php if($ext=="jpg" || $ext=="jpeg" || $ext=="png"): ?>
                        <p><img src='<?php echo e(asset($question->mfile_ext)); ?>' style='width:250px;height:200px'></p>
                        <?php elseif($ext=="mp3" || $ext=="mp4"): ?>
                        <p>
                            <video width="250" height="200" controls>
                                <?php if($ext=="mp3"): ?>
                                    <source src="<?php echo e(asset($question->mfile_ext)); ?>" type="video/mp3">
                                <?php else: ?> 
                                    <source src="<?php echo e(asset($question->mfile_ext)); ?>" type="video/mp4">
                                <?php endif; ?>
                            </video>
                        </p>
                        
                        <?php elseif($ext=="pdf"): ?>
                        <p><?php echo e(asset($question->mfile_ext)); ?></p>
                        <?php endif; ?>
                    <?php endif; ?>
                    <div class="control-group">
                    <lable class="control-label" for="options">Options</label>
                    <div class="controls">
                    <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type="text" name="options[]" class="span7" value="<?php echo e($answer->answer); ?>" required=""> 
                        
                        <input type="radio" name="correct_answer" value="<?php echo e($key); ?>" <?php if($answer->is_correct): ?><?php echo e('checked'); ?> <?php endif; ?>>
                        <span>Is correct answer</spam>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                   <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                

                    <div class="control-group">
                        <div class="controls">
                            <button type="submit" class="btn btn-success">Submit</button>
</div>
</div>
</form>

</div>
</div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tinymce/5.10.2/tinymce.min.js"></script>
    <script>
		tinymce.init({
		  selector: '#mceDEMO',
		  width: 754 - 2,
		  height: 372 - 99,
		  plugins: [
			'advlist',
			'autolink',
			'lists',
			'link',
			'image',
			'charmap',
			'print',
			'preview',
			'anchor',
			'searchreplace',
			'visualblocks',
			'code',
			'fullscreen',
			'insertdatetime',
			'media',
			'table',
			'contextmenu',
			'paste',
			'imagetools'
		  ],
		  toolbar: 'undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist | link image',
		  
	});
	
	

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/schooldr/public_html/cbt.schooldrive.com.ng/resources/views/backend/question/edit.blade.php ENDPATH**/ ?>