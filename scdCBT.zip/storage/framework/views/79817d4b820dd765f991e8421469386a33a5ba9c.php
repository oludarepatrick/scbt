    <?php $__env->startSection('title','User Result'); ?>
    
    <?php $__env->startSection('content'); ?>
    <div class="span9">
        <div class="content">
        <?php if(Session::has('message')): ?>

            <div class="alert alert-success"><?php echo e(Session::has('message')); ?></div>
        <?php endif; ?>
        <div class="module">
                <div class="module-head">
                        <h3>User Result</h3>
                        </div>
                <div class="module-body">
                <table class="table table-stripped">
                    <thead>
                    <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th></th>
                    </tr>
                    </thead>
                    </tbody>
                    <?php if(count($quizzes)>0): ?>
                    <?php $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $quiz->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($key+1); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($quiz->name); ?></td>
                    <td><a href="result/<?php echo e($user->id); ?>/<?php echo e($quiz->id); ?>">
                        <button class="btn btn-primary">View Result</button></a>
                    </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php else: ?>
                    <td>No user Result to display</td>
                    <?php endif; ?>

                    </tbody>
                    </table>
                    </div>
                    </div>
                    </div>
                    </div>
                    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/schooldrive/drivequiz.schooldriveng.com/resources/views/backend/result/index.blade.php ENDPATH**/ ?>