    <?php $__env->startSection('title','create quiz'); ?>
    
    <?php $__env->startSection('content'); ?>
    
    
    <div class="span9">
        <div class="content">
            <?php if(Session::has('message')): ?>
                <div class="alert alert-success"><?php echo e(Session::get('message')); ?></div>
            <?php endif; ?>

            <!--<form  method="POST" id="search">-->
            
                <div class="module">
                    <div class="module-head">
                            <h3>Re-Assign Exam</h3>
                    </div>

                    <div class="module-body">
                        <div class="table-responsive">
                            <div class="col-sm-6 col-md-6 col-lg-6">
                                
                                <div class="mb-3">
                                    <label class="form-label">Arm (Optional)</label>
                                    <select name="arm" class="filter form-control <?php $__errorArgs = ['arm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> span6" id="armId">
                                        <option value="optional">-Select Arm (Optional)-</option>
                                        <?php $__currentLoopData = $arms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($arm->division); ?>"><?php echo e($arm->division); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['arm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                        
                                <div class="mb-3">
                                    <label class="form-label">Select Class</label>
                                    <select name="classname" class="filter form-control <?php $__errorArgs = ['classname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> span6" onChange="displaySubject(this.value)" id="classId">
                                        <option>Select Class</option>
                                        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($class->class); ?>"><?php echo e($class->class); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['classname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                
                                <div class="mb-3">
                                    <label class="form-label">Quiz Title</label>
                                    <select name="quiz" class="filter form-control <?php $__errorArgs = ['quiz'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> span6" id="quiz">
                                        <option>Select Quiz</option>
                                        
                                    </select>
                                    <?php $__errorArgs = ['quiz'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                            </div>
                            <div class="col-sm-6 col-md-6">
                                
                            </div>
                        </div>
                        <div class="control-group">
                            <div class="controls">
                                <button type="submit" class="btn btn-success" id='btn_ajax' onClick="doThis()">Load Students</button>
                            </div>
                        </div>
                        
                        <div class="col-sm-6 col-md-6 data" id="dataM">
                                        
                        </div>
                    </div>
                </div>
            <!--</form>-->
            <!--<script src="<?php echo e(asset('js/jquery.form.js')); ?>"></script>-->
            
            
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<script>
    //sends data to server, via POST, and displays the received answer
    var customURL = "<?= asset('images/loader.gif'); ?>";

    function displaySubject(value)
    {
        //var classId=document.getElementById('classId').value;
        var armId=document.getElementById('armId').value;

        var see_resp = document.getElementById('quiz');
        var req = (window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');  // XMLHttpRequest object

        var data ='_token=<?php echo e(csrf_token()); ?>&armId='+armId+'&cId='+value;

        req.open('POST', 'loadsquizes', true); // set the request

        //adds header for POST request
        req.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

        req.send(data); //sends data
        req.onreadystatechange = function()
        {
            if(req.readyState ==4 && req.status==200)
            {
                see_resp.innerHTML = req.responseText;
            }
            else{
                see_resp.innerHTML ="<img src='"+customURL+"'> <b> Please wait,Loading... </b>";
            }
            
        }
    }

    function doThis()
    {
        var classId=document.getElementById('classId').value;
        var armId=document.getElementById('armId').value;
        var quizId=document.getElementById('quiz').value;

        var see_resp = document.getElementById('dataM');
        var req = (window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');  // XMLHttpRequest object

        //pairs index=value with data to be sent to server (including csrf_token)
        //var data ='_token=<?php echo e(csrf_token()); ?>&cId='+classId+'&armId'+armId;
        var data ='_token=<?php echo e(csrf_token()); ?>&armId='+armId+'&cId='+classId+'&quizId='+quizId;

        
        req.open('POST', 'loadstudreasign', true); // set the request

        //adds header for POST request
        req.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

        req.send(data); //sends data

        // If the response is successfully received, will be added in #see_resp
        req.onreadystatechange = function()
        {
            if(req.readyState ==4 && req.status==200)
            {
                //alert(req.responseText); //just for debug
                see_resp.innerHTML = req.responseText;
            }
            else{
                see_resp.innerHTML ="<img src='"+customURL+"'> <b> Please wait,Loading... </b>";
            }
            
        }
    }
</script>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/schooldrive/cbt.schooldriveng.com/resources/views/backend/exam/re-assign.blade.php ENDPATH**/ ?>