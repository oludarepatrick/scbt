    <?php $__env->startSection('title','create question'); ?>
    
    <?php $__env->startSection('content'); ?>
    <div class="span9">
        <div class="content">
        <?php if(Session::has('message')): ?>

            <div class="alert alert-success"><?php echo e(Session::get('message')); ?></div>
        <?php endif; ?>
        <div class="module">
                <div class="module-head">
                        <h3>All Question</h3>
                        </div>
                <div class="module-body">
                    <p><h3 class="heading"><?php echo e($question->question); ?></h3></p>

                    <div class="module-body table">
                        <table class="table table-message">
                            <tbody>
                                <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="read">
                                    <td class="cell-author hidden-phone hidden-tablet">
                                    <?php echo e($key+1); ?>.<?php echo e($answer->answer); ?>

                                        <?php if($answer->is_correct): ?>
                                        <span class="badge badge-success pull-right">correct</b></span>
                                        <?php endif; ?>
                                    </td>
                                        
                                </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>
<div class="module-foot">
  <a href="<?php echo e(route('question.edit',[$question->id])); ?>">
    <button class="btn btn-primary">Edit</button></a>

    <form id="delete-form<?php echo e($question->id); ?>" method="POST" action="<?php echo e(route('question.destroy',[$question->id])); ?>"><?php echo csrf_field(); ?>
        <?php echo e(method_field('DELETE')); ?>

    </form>
    <a href="" onclick="if(confirm('Do you want to delete?')){
        event.preventDefault();
        document.getElementById('delete-form<?php echo e($question->id); ?>').submit()
     }else{
        event.preventDefault();
        }

        ">
      <input type="submit" value="Delete" class="btn btn-danger">
    </a>
    

   <a href="<?php echo e(route('question.index')); ?>"> <button class="btn btn-inverse pull-right">Back</button></a>
        </div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/schooldr/public_html/drivestores/resources/views/backend/question/show.blade.php ENDPATH**/ ?>