    <?php $__env->startSection('title','create quiz'); ?>
    
    <?php $__env->startSection('content'); ?>

    <div class="span9">
        <div class="content">

        <?php if(Session::has('message')): ?>

            <div class="alert alert-success"><?php echo e(Session::get('message')); ?></div>
        <?php endif; ?>
        
        <form action="<?php echo e(route('question.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="module">
                <div class="module-head">
                        <h3>Create Question</h3>
                </div>

                <div class="module-body">
                    <div class="control-group">
                    <lable class="control-label" for="question">Choose Quiz</label>
                    <div class="controls">
                    <select name="quiz" class="span8" onChange="displayQNo(this.value)" required>
                    <option>Select Quiz</option>
                    <?php $__currentLoopData = $quizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       
                        <option value="<?php echo e($quiz->id); ?>"><?php echo e($quiz->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                        
                    </div>
                   <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>


                    <div class="control-group">
                    <lable class="control-label" for="question" style="font-size: 18px; color:darkblue">Question Name(No. <strong id="qNo"></strong>)</label>
                        <div class="controls">
                        <!--<input type="text" name="question" class="span8" placeholder="question of a quiz" value="<?php echo e(old('question')); ?>">-->
                        <textarea id="mceDEMO" name="question" class="span8"></textarea>
                    </div>
                    <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="control-group">
                        <lable class="control-label" for="question">Upload File(if any)</label>
                        <div class="controls">
                            <input type="file" name="mfile" class="span8" placeholder="Upload file" value="<?php echo e(old('mfile')); ?>">
                        </div>
                        <strong style='color:red; font-size:13px'>file supported type: jpg,png,mp3,mp4,pdf</strong>
                        <?php $__errorArgs = ['mfile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                   

                    <div class="control-group" style="padding-left:10px">
                    <lable class="control-label" for="options">Options</label>
                    <div class="controls">
                    <?php for($i=0;$i<4;$i++): ?>
                        <?php 
                            if($i==0){ $defltVal="A"; }
                            elseif($i==1){ $defltVal="B"; }
                            elseif($i==2){ $defltVal="C"; }
                            elseif($i==3){ $defltVal="D"; }
                        ?>
                        <input type="text" name="options[]" class="span6 <?php $__errorArgs = ['options'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="options<?php echo e($i+1); ?>" value="<?php echo e((!empty(old('options.[$i]'))?old('options.[$i]'):$defltVal)); ?>" required="">
                        
                        <input type="radio" name="correct_answer" value="<?php echo e($i); ?>">
                        <span>Is correct answer</spam>
                    <?php endfor; ?>
                    </div>
                   <?php $__errorArgs = ['options'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                

                    <div class="control-group" style="padding-left:20px">
                        <div class="controls">
                            <button type="submit" class="btn btn-success">Submit</button>
                        </div>
                    </div>
</form>

</div>
</div>
</div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/tinymce/5.10.2/tinymce.min.js"></script>
    <script>
		tinymce.init({
		  selector: '#mceDEMO',
		  width: 754 - 2,
		  height: 372 - 99,
		  plugins: [
			'advlist',
			'autolink',
			'lists',
			'link',
			'image',
			'charmap',
			'print',
			'preview',
			'anchor',
			'searchreplace',
			'visualblocks',
			'code',
			'fullscreen',
			'insertdatetime',
			'media',
			'table',
			'contextmenu',
			'paste',
			'imagetools'
		  ],
		  toolbar: 'undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist | link image',
		  
	});
	
	var customURL = "<?= asset('images/loader.gif'); ?>";
    function displayQNo(value)
    {
        var see_resp = document.getElementById('qNo');
        
        var req = (window.XMLHttpRequest) ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');  // XMLHttpRequest object

        var data ='_token=<?php echo e(csrf_token()); ?>&quizId='+value;

        req.open('POST', 'loadquestion', true); // set the request

        //adds header for POST request
        req.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

        req.send(data); //sends data
        req.onreadystatechange = function()
        {
            if(req.readyState ==4 && req.status==200)
            {
                see_resp.innerHTML = req.responseText;
            }
            else{
                see_resp.innerHTML ="<img src='"+customURL+"'> <b> Please wait,Loading... </b>";
            }
            
        }
    }

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/schooldrive/cbt.schooldriveng.com/resources/views/backend/question/create.blade.php ENDPATH**/ ?>