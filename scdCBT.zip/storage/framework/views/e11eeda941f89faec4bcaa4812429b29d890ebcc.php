<?php $__env->startSection('content'); ?>

<next-component
    :times ="<?php echo e($quiz->minutes); ?>"
    :quizId="<?php echo e($quiz->id); ?>"
    :quiz-questions = "<?php echo e($quizQuestions); ?>"
    :has-quiz-played ="<?php echo e($authUserHasPlayedQuiz); ?>" 
    >

</next-component>
<script type="text/javascript">
    window.oncontextmenu = function(){
        console.log("Right Click Disabled");
        return false;
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/patrick/quizapp4/resources/views/quiz.blade.php ENDPATH**/ ?>