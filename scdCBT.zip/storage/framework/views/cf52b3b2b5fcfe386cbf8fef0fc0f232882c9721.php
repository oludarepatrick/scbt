    <?php $__env->startSection('title','Quiz Questions'); ?>
    
    <?php $__env->startSection('content'); ?>

    <div class="span9">
        <div class="content">
        <?php $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="module">
        <div class="module-head">

        <h3>
            <?php echo e($quiz->name); ?>

            
        </h3>
        </div>

        <div class="module-body">

        <p><h3 class="heading"></h3></p>

        <div class="module-body table">

        <?php $__currentLoopData = $quiz->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ques): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <table class="table table-message">
        <tbody>
        <span style='float:right'><a href="<?php echo e(route('question.edit',[$ques->id])); ?>" class="btn btn-info btn-sm">Edit Question</a></span>
        <tr class="read">
        
        <?php echo $ques->question; ?>

        
        

        <td class="cell-autho hidden-phone hidden-tablet">
        <?php if(!empty($ques->mfile_ext)): ?>
                        <?php 
                            
                            list($txt,$ext)=explode(".", $ques->mfile_ext);
                            $ext=strtolower($ext);
                            
                        ?>
                        <?php if($ext=="jpg" || $txt=="jpeg"): ?>
                        <p><img src='<?php echo e(asset($ques->mfile_ext)); ?>' style='width:250px;height:200px'></p>
                        <?php elseif($ext=="mp3" || $ext=="mp4"): ?>
                        <p>
                            <video width="250" height="200" controls>
                                <?php if($ext=="mp3"): ?>
                                    <source src="<?php echo e(asset($ques->mfile_ext)); ?>" type="video/mp3">
                                <?php else: ?> 
                                    <source src="<?php echo e(asset($ques->mfile_ext)); ?>" type="video/mp4">
                                <?php endif; ?>
                            </video>
                        </p>
                        
                        <?php elseif($ext=="pdf"): ?>
                        <p><?php echo e(asset($ques->mfile_ext)); ?></p>
                        <?php endif; ?>
                    <?php endif; ?>

        <?php $__currentLoopData = $ques->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p>
        <?php echo $answer->answer; ?>

       <?php if($answer->is_correct): ?>
        <span class="badge badge-success">
        correct answer
    </span>
    <?php endif; ?>
    </p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </td>
    <tr>
    </tbody>
    </table>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="module-foot">
    <td>
    <a href="<?php echo e(route('quiz.index')); ?>"><button class="btn btn-inverse pull-center">Back</button></a>
    </td>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/schooldr/public_html/cbt.schooldrive.com.ng/resources/views/backend/quiz/question.blade.php ENDPATH**/ ?>