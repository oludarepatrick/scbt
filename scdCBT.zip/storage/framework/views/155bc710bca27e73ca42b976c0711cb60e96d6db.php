    <?php $__env->startSection('title','Exam Assigned User'); ?>
    
    <?php $__env->startSection('content'); ?>
    <div class="span9">
        <div class="content">
        <?php if(Session::has('message')): ?>

            <div class="alert alert-success"><?php echo e(Session::get('message')); ?></div>
        <?php endif; ?>
        <div class="module">
                <div class="module-head">
                        <h3>All Quiz</h3>
                        </div>
                <div class="module-body">
                <table class="table table-stripped">
                    <thead>
                    <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Quiz</th>
                    <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if(count($quizzes)>0): ?>
                    <?php $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $quiz->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e($key+1); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($quiz->name); ?></td>
                    <td>
                        <a href="<?php echo e(route('quiz.question',[$quiz->id])); ?>"><button class="btn btn-inverse">View Questions</button>
                        </a>
                    </td>
                   <td>
                   <form action="<?php echo e(route('exam.remove')); ?>" method="POST"><?php echo csrf_field(); ?>
                   <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                   <input type="hidden" name="quiz_id" value="<?php echo e($quiz->id); ?>">
                   <button class="btn btn-danger" type="submit">Remove</button>
                   </form>
                   </td>
                  
                   
                       





                    </tr>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                   <?php else: ?>
                   <td>No User to Display</td>
                   <?php endif; ?>
                    </tbody>
                    </table>
                    </div>
                    </div>
                    </div>
                    </div>
                    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/schooldrive/cbt.schooldriveng.com/resources/views/backend/exam/index.blade.php ENDPATH**/ ?>