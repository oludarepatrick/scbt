<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
    <div class="col-nd-8">
    <centre><h2>Your Result</h2></centre>
    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card">
        <div class="card-header"><?php echo e($key+1); ?></div>
        <div class="card-body">
        <p>
        <h3>
        <?php echo e($result->question->question); ?>

        </h3>
        </p>

        <?php
        $i=1;

        $answers = DB::table('answers')->where('question_id',$result->question_id)->get();
        foreach($answers as $ans){
            echo '<p>'.$i++.')' .$ans->answer.
            '</p>';

        }
        ?>
        <p><mark>
        Your answer: <?php echo e($result->answer->answer); ?></mark>
        </p>
        <?php
            $correctAnswers = DB::table('answers')->where('question_id',$result->question_id)->where('is_correct',1)->get();

            foreach($correctAnswers as $ans){
                echo "Correct Answer:".$ans->answer;
            }
        ?>
        <?php if($result->answer->is_correct): ?>
            <p>
                <span class="btn btn-success">Result: Correct</span>
            </p>
            <?php else: ?>
            <p>
                <span class="btn btn-danger">Result: Incorrect</span>
            </p>
        <?php endif; ?>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/schooldrive/drivequiz.schooldriveng.com/resources/views/result-detail.blade.php ENDPATH**/ ?>