<?php if(count($quizes)): ?>
    <option value="">--select subjects--</option>  
<?php endif; ?>

<?php $__empty_1 = true; $__currentLoopData = $quizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <option value="<?php echo e($quiz->id); ?>"><?php echo e($quiz->name." (".$quiz->subject_id.")"); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <option value="">No Available Quiz</option> 
<?php endif; ?>
<?php /**PATH /home/schooldr/public_html/drivestores/resources/views/backend/exam/load-quiz-title.blade.php ENDPATH**/ ?>